package org.example.Vista;

import org.example.ControladorDAO.ClienteDAO;
import org.example.Modelo.Cliente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarCliente extends JFrame {


    public ModificarCliente(Cliente cliente){
        setTitle("Modificar Clientes");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5,2,5,5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel dni = new JLabel(" DNI");
        JLabel telefono = new JLabel("telefono");
        JLabel correo = new JLabel("Correo");




        JTextField escribirDni = new JTextField(cliente.getDni());
        escribirDni.setEditable(false);
        JTextField escribirTelefono = new JTextField(cliente.getTelefono());
        JTextField escribirCorreo = new JTextField(cliente.getCorreo());



        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(dni);
        panelModificar.add(escribirDni);
        panelModificar.add(telefono);
        panelModificar.add(escribirTelefono);
        panelModificar.add(correo);
        panelModificar.add(escribirCorreo);



        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String telefono =  escribirTelefono.getText().trim();
                String correo = escribirCorreo.getText().trim();
                String dni = escribirDni.getText().trim();


                Cliente cliente = new Cliente(telefono,correo,dni);

                if (ClienteDAO.actualizarCliente(cliente)){
                    JOptionPane.showMessageDialog(null,"Usuario Cambiado con exito");
                }else {
                    JOptionPane.showMessageDialog(null," No se ha podido cambiar");
                }

                escribirCorreo.setText("");
                escribirTelefono.setText("");


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerCliente interfazVerCliente = new InterfazVerCliente();
                dispose();
            }
        });


    }


    public static void main(String[] args) {
        ModificarCliente modificarCliente = new ModificarCliente(new Cliente());
        modificarCliente.setVisible(true);
    }
}
