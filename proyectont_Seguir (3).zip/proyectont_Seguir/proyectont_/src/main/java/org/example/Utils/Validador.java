package org.example.Utils;

public class Validador {

    public static boolean comprobarNombre(String usuario) {
        return usuario.matches("^[A-Za-zÁÉÍÓÚáéíóú]{3,25}$");
    }

    public static boolean comprobarDNI(String usuario) {
        return usuario.matches("^[0-9]{8}[A-Z]$");
    }

    public static boolean comprobarTelefono(String usuario) {
        return usuario.matches("^[6-9]{1}[0-9]$");
    }
    public static boolean comprobarCorreo(String correo){
        return  correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    }




}
