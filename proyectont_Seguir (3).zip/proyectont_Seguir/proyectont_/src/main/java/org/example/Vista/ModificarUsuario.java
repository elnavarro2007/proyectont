package org.example.Vista;

import org.example.ControladorDAO.TiendaDAO;
import org.example.ControladorDAO.UsuarioDAO;
import org.example.Modelo.Tienda;
import org.example.Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarUsuario extends JFrame {
    public ModificarUsuario(Usuario usuario) {

        setTitle("Modificar Usuarios");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(6, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("dni");
        JLabel nombre = new JLabel(" nombre");
        JLabel password = new JLabel("password");


        JTextField escribirID = new JTextField(usuario.getId());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(usuario.getNombre());
        escribirNombre.setEditable(false);
        JTextField escribirPassword = new JTextField(usuario.getPassword());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(password);
        panelModificar.add(escribirPassword);

        //  panelModificar.add(passwd);

        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre = escribirNombre.getText().trim();
                String passwd = escribirPassword.getText().trim();

                Usuario usuario1 = new Usuario(id,nombre,passwd);

                if (UsuarioDAO.actualizarUsuario(usuario1)) {
                    JOptionPane.showMessageDialog(null, "Datos Cambiados con exito");
                } else {
                    JOptionPane.showMessageDialog(null, " No se ha podido cambiar");
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerUsuarios interfazVerUsuarios = new InterfazVerUsuarios();
                dispose();
            }
        });
    }
}

