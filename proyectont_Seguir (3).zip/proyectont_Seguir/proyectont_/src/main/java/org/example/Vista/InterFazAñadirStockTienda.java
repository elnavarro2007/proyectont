package org.example.Vista;

import org.example.ControladorDAO.TiendaDAO;
import org.example.Modelo.Tienda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterFazAñadirStockTienda extends JFrame {
    public InterFazAñadirStockTienda() {
        setTitle("seleccionar Tienda");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");


        ArrayList<Tienda> tiendas = TiendaDAO.verTienda();

        DefaultListModel<Tienda> modelo = new DefaultListModel<>();
        JList<Tienda> listaTienda = new JList<>(modelo);

        for (Tienda t : tiendas) {
            modelo.addElement(t);
        }


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(listaTienda);
        scroll.setPreferredSize(new Dimension(550, 250));
        panelBotones.add(volver);
        panelBotones.add(seleccionar);


        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                dispose();
            }
        });
        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Tienda seleccionada = listaTienda.getSelectedValue();

                if (seleccionada == null) {
                    JOptionPane.showMessageDialog(null, "Cliente no seleccionado");
                } else {


                    InterfazAñadirStockVideojuego interfazAñadirStockVideojuego = new InterfazAñadirStockVideojuego(seleccionada);
                    dispose();
                   // new InterfazVerCliente().setVisible(false);

                }
            }
        });
    }


    public static void main(String[] args) {
        InterFazAñadirStockTienda interFazAñadirStock = new InterFazAñadirStockTienda();
        interFazAñadirStock.setVisible(true);
    }
}
