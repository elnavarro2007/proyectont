package org.example.Vista;

import org.example.ControladorDAO.ClienteDAO;
import org.example.Modelo.Cliente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazSeleccionarClienteUsuario extends JFrame {
    public InterfazSeleccionarClienteUsuario() {
        setTitle("seleccionar Cliente");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");


        ArrayList<Cliente> clientes = ClienteDAO.verCliente();

        DefaultListModel<Cliente> modelo = new DefaultListModel<>();
        JList<Cliente> listaCliente = new JList<>(modelo);

        for (Cliente c : clientes) {
            modelo.addElement(c);
        }


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(listaCliente);
        scroll.setPreferredSize(new Dimension(550, 250));
        panelBotones.add(volver);
        panelBotones.add(seleccionar);


        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTickets interfazGestionTickets = new InterfazGestionTickets();
                dispose();
            }
        });
        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cliente seleccionada = listaCliente.getSelectedValue();

                if (seleccionada == null) {
                    JOptionPane.showMessageDialog(null, "Cliente no seleccionado");
                } else {


                    InterfazAñadirUsuario interfazAñadirUsuario = new InterfazAñadirUsuario(seleccionada);
                    dispose();
                    // new InterfazVerCliente().setVisible(false);

                }
            }
        });
    }
}
