package org.example.Vista;

import org.example.ControladorDAO.TiendaDAO;
import org.example.ControladorDAO.VideojuegoDAO;
import org.example.Modelo.Tienda;
import org.example.Modelo.Videojuegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarVideojuegos extends JFrame{
    public ModificarVideojuegos(Videojuegos videojuegos) {

        setTitle("Modificar tiendas");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(6,2,5,5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("numero serie");
        JLabel genero = new JLabel(" genero");

        JLabel precio = new JLabel("Precio");




        JTextField escribirID = new JTextField(videojuegos.getNumeroSerie());
        escribirID.setEditable(false);

        JTextField escribirGenero = new JTextField(videojuegos.getGenero());
        JTextField escribirPrecio = new JTextField(videojuegos.getPrecio());



        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(genero);
        panelModificar.add(escribirGenero);
        panelModificar.add(precio);
        panelModificar.add(escribirPrecio);


        //  panelModificar.add(passwd);

        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String genero =  escribirGenero.getText().trim();
                String precio = escribirPrecio.getText().trim();








                Videojuegos videojuegos1 = new Videojuegos(id,genero,precio);




                if (VideojuegoDAO.actualizarVideojuego(videojuegos1)){
                    JOptionPane.showMessageDialog(null,"Datos Cambiados con exito");
                }else {
                    JOptionPane.showMessageDialog(null," No se ha podido cambiar");
                }




            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerVideojuegos interfazVerVideojuegos = new InterfazVerVideojuegos();
                dispose();
            }
        });
    }
}
