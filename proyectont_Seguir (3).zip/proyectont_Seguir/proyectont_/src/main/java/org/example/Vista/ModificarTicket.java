package org.example.Vista;

import org.example.ControladorDAO.TicketCompraDAO;
import org.example.ControladorDAO.TiendaDAO;
import org.example.Modelo.TicketCompra;
import org.example.Modelo.Tienda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarTicket extends JFrame {
    public ModificarTicket(TicketCompra ticketCompra) {
        setTitle("Modificar Ticket");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(4,2,5,5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("ID COMPRA");
        JLabel numSerie = new JLabel(" numero_serie");
        JLabel precio = new JLabel("precio");





        JTextField escribirID = new JTextField(ticketCompra.getDNI()); // parseo el id del ticket para que me lo pille
        escribirID.setEditable(false);
        JTextField escribirSerie = new JTextField(ticketCompra.getNumSerie());
        JTextField escribirPrecio = new JTextField(ticketCompra.getPrecio());




        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(numSerie);
        panelModificar.add(escribirSerie);
        panelModificar.add(precio);
        panelModificar.add(escribirPrecio);


        //  panelModificar.add(passwd);

        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String serie =  escribirSerie.getText().trim();
                String precio = escribirPrecio.getText().trim();


                TicketCompra ticketCompra1 = new TicketCompra(id, serie,precio);










                if (TicketCompraDAO.actualizarTicket(ticketCompra1)){
                    JOptionPane.showMessageDialog(null,"Datos Cambiados con exito");
                }else {
                    JOptionPane.showMessageDialog(null," No se ha podido cambiar");
                }




            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTicketsAdmin interfazVerTicketsAdmin = new InterfazVerTicketsAdmin();
                dispose();
            }
        });
    }
}
