package org.example.Configuracion;

public class ArchivoLogin {
}
