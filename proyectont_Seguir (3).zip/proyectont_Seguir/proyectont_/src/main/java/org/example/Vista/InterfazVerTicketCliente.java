package org.example.Vista;

import org.example.ControladorDAO.TicketCompraDAO;
import org.example.Modelo.Cliente;
import org.example.Modelo.TicketCompra;
import org.example.Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazVerTicketCliente extends JFrame {
    Usuario user;

    public InterfazVerTicketCliente(Usuario usuario) {

        this.user = usuario;
        setTitle("Ver Tickets  ");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");


        ArrayList<TicketCompra> ticketCompras = TicketCompraDAO.verTicketCliente(usuario);

        DefaultListModel<TicketCompra> modelo = new DefaultListModel<>();
        JList<TicketCompra> listaTickets = new JList<>(modelo);

        for (TicketCompra t : ticketCompras) {
            modelo.addElement(t);
        }


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(listaTickets);
        scroll.setPreferredSize(new Dimension(550, 250));
        panelBotones.add(volver);


        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelCliente interfazGestionTienda = new InterfazDelCliente(usuario);
                dispose();
            }
        });

    }

    public static void main(String[] args) {

    }
}
