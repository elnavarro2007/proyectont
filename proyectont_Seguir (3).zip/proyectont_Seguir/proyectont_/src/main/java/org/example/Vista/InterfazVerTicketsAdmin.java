package org.example.Vista;

import org.example.ControladorDAO.TicketCompraDAO;
import org.example.ControladorDAO.TiendaDAO;
import org.example.Modelo.TicketCompra;
import org.example.Modelo.Tienda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazVerTicketsAdmin extends JFrame {

    public InterfazVerTicketsAdmin() {

        setTitle("Ver Tickets ");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton actualizar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");


        ArrayList<TicketCompra> ticketCompras = TicketCompraDAO.verTicket();

        DefaultListModel<TicketCompra> modelo = new DefaultListModel<>();
        JList<TicketCompra> listaTickets = new JList<>(modelo);

        for (TicketCompra t : ticketCompras) {
            modelo.addElement(t);
        }


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(listaTickets);
        scroll.setPreferredSize(new Dimension(550, 250));
        panelBotones.add(volver);
        panelBotones.add(actualizar);
        panelBotones.add(eliminar);

        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTickets interfazGestionTienda = new InterfazGestionTickets();
                dispose();
            }
        });
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TicketCompra seleccionado = listaTickets.getSelectedValue();


                if (seleccionado == null) {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado ningun usuario");
                } else {
                    int respuesta = JOptionPane.showConfirmDialog(null, "Seguro que quieres eliminar el usuario", "Si, no", JOptionPane.YES_NO_OPTION);
                    if (respuesta == JOptionPane.YES_OPTION) {
                        boolean eliminado = TicketCompraDAO.eliminarCompra(seleccionado);
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                        dispose();
                        new InterfazVerTicketsAdmin().setVisible(true);

                    }
                    if (respuesta == JOptionPane.NO_OPTION) {

                    }
                }
            }
        });

        actualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                TicketCompra seleccionado = listaTickets.getSelectedValue();

                if (seleccionado == null) {
                    JOptionPane.showMessageDialog(null, "Ticket no seleccionada");
                } else {


                    ModificarTicket modificarTicket = new ModificarTicket(seleccionado);
                    dispose();
                    new InterfazVerTicketsAdmin().setVisible(false);

                } // Preguntar a angel para que me pille el dni sin tener que escribirlo
                // y para que no se abran nuevas interfaces mientras modificarCliente este activo


            }
        });
    }

    static void main(String[] args) {
        InterfazVerTicketsAdmin interfazVerTicketsAdmin = new InterfazVerTicketsAdmin();
        interfazVerTicketsAdmin.setVisible(true);
    }
}
