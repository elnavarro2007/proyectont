package org.example.Vista;

import org.example.ControladorDAO.TiendaDAO;
import org.example.ControladorDAO.VideojuegoDAO;
import org.example.Modelo.Tienda;
import org.example.Modelo.Videojuegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazAñadirStockVideojuego extends JFrame {
    private Tienda tienda;
    public InterfazAñadirStockVideojuego(Tienda tienda) {
        this.tienda = tienda;
        setTitle("seleccionar Videojuego");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");


        ArrayList<Videojuegos> videojuegos = VideojuegoDAO.verVideojuegos();

        DefaultListModel<Videojuegos> modelo = new DefaultListModel<>();
        JList<Videojuegos> listaVideojuegos = new JList<>(modelo);

        for (Videojuegos v : videojuegos) {
            modelo.addElement(v);
        }


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(listaVideojuegos);
        scroll.setPreferredSize(new Dimension(550, 250));
        panelBotones.add(volver);
        panelBotones.add(seleccionar);


        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                dispose();
            }
        });
        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Videojuegos seleccionada = listaVideojuegos.getSelectedValue();

                if (seleccionada == null) {
                    JOptionPane.showMessageDialog(null, "Videojuego no seleccionado");
                } else {

                    new InterfazAñadirStockElementosIncluidos(tienda,seleccionada).setVisible(true);

                    dispose();


                }
            }
        });
    }
}
