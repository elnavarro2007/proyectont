package org.example.Vista;

import org.example.Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazDelCliente extends JFrame {
    Usuario user;

    public InterfazDelCliente(Usuario usuario) {
        this.user = usuario;


        setTitle("interfaz Cliente");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        // Panel principal 3 filas, 2 columnas
        JPanel panel = new JPanel(new GridLayout(1, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setVisible(true);
        setResizable(false);

        JButton botonTicket = new JButton("Ver Tickets");
        JButton botonModificarContrasena = new JButton("Modificar Contraseña");


        panel.add(botonTicket);
        panel.add(botonModificarContrasena);

        add(panel);

        botonTicket.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTicketCliente interfazVerTicketCliente = new InterfazVerTicketCliente(usuario);
                dispose();
            }
        });

        botonModificarContrasena.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ModificarUsuarioInterfazCliente modificarUsuarioInterfazCliente = new ModificarUsuarioInterfazCliente(usuario);
                dispose();
            }
        });


    }

    public static void main(String[] args) {
        InterfazLogin interfazLogin = new InterfazLogin();
        interfazLogin.setVisible(true);
    }
}
