package org.example.Vista;

import org.example.ControladorDAO.ClienteDAO;
import org.example.ControladorDAO.TiendaDAO;
import org.example.Modelo.Cliente;
import org.example.Modelo.Tienda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ModificarTienda extends JFrame {
    public ModificarTienda( Tienda tienda) {

        setTitle("Modificar tiendas");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(6,2,5,5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("id");
        JLabel nombre = new JLabel(" nombre");
        JLabel telefono = new JLabel("telefono");
        JLabel ubicacion = new JLabel("ubicacion");
        JLabel correo = new JLabel("Correo");




        JTextField escribirID = new JTextField(tienda.getId());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(tienda.getNombreTienda());
        JTextField escribirTelefono = new JTextField(tienda.getTelefono());
        JTextField escribirUbicacion = new JTextField(tienda.getUbicacion());
        JTextField escribirCorreo = new JTextField(tienda.getCorreo());



        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(telefono);
        panelModificar.add(escribirTelefono);
        panelModificar.add(ubicacion);
        panelModificar.add(escribirUbicacion);
        panelModificar.add(correo);
        panelModificar.add(escribirCorreo);

      //  panelModificar.add(passwd);

        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre =  escribirNombre.getText().trim();
                String telefono = escribirTelefono.getText().trim();
                String ubicacion = escribirUbicacion.getText().trim();
                String correo = escribirCorreo.getText().trim();







                Tienda tiendas = new Tienda(nombre,telefono,ubicacion,correo, id);




                if (TiendaDAO.actualizarTienda(tiendas)){
                    JOptionPane.showMessageDialog(null,"Datos Cambiados con exito");
                }else {
                    JOptionPane.showMessageDialog(null," No se ha podido cambiar");
                }




            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTienda interfazVerTienda = new InterfazVerTienda();
                dispose();
            }
        });
    }
}
