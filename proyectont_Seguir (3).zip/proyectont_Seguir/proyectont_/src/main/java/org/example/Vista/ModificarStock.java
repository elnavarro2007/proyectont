package org.example.Vista;

import org.example.ControladorDAO.ClienteDAO;
import org.example.ControladorDAO.TiendaVideojuegoDAO;
import org.example.Modelo.Cliente;
import org.example.Modelo.TiendaVideojuegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarStock extends JFrame {
    public ModificarStock(TiendaVideojuegos tiendaVideojuegos) {
        setTitle("Modificar Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5,2,5,5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel(" id_tienda");
        JLabel numSerie = new JLabel("numero Serie");
        JLabel stock = new JLabel("Stock");


        JLabel passwd = new JLabel("contraseña");

        JTextField escribirID = new JTextField(tiendaVideojuegos.getId_tienda());
        escribirID.setEditable(false);
        JTextField escribiSerie = new JTextField(tiendaVideojuegos.getNum_serie());
        JTextField escribirStock = new JTextField(tiendaVideojuegos.getStock());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(numSerie);
        panelModificar.add(escribiSerie);
        panelModificar.add(stock);
        panelModificar.add(escribirStock);
        panelModificar.add(modificar);
        panelModificar.add(volver);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id =  escribirID.getText().trim();
                String numSerie = escribiSerie.getText().trim();
                String stock = escribirStock.getText().trim();



                TiendaVideojuegos tiendaVideojuegos1 = new TiendaVideojuegos(id,numSerie,stock);


                if (TiendaVideojuegoDAO.modificarStock(tiendaVideojuegos1)){
                    JOptionPane.showMessageDialog(null,"Usuario Cambiado con exito");
                }else {
                    JOptionPane.showMessageDialog(null," No se ha podido cambiar");
                }




            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerStock interfazVerStock = new InterfazVerStock();
                dispose();
            }
        });
    }
}
