-- Base de datos de tienda de juegos parte de programaciob




-- CREO LA BASE SI NO EXISTE
CREATE DATABASE if not EXISTS tiendaDeVideojuegos;

USE tiendaDeVideojuegos;


CREATE TABLE tienda (
	id int PRIMARY key AUTO_INCREMENT,
	nombre_tienda VARCHAR(30) NOT NULL,
	telefono int(9) NOT NULL,
	ubicacion VARCHAR(40) NOT NULL,
	correo varchar(50) NOT NULL UNIQUE
	
);

CREATE table cliente (

	dni CHAR(9) PRIMARY KEY,
	nombre VARCHAR(30) NOT NULL,
	apellidos VARCHAR(50) NOT NULL,
	telefono CHAR(9) NOT NULL,
	correo VARCHAR(150)NOT NULL UNIQUE





);


create table videojuego (

	numero_serie CHAR(9)  PRIMARY KEY UNIQUE,
	nombre VARCHAR(30) not null UNIQUE,
	genero VARCHAR(20) NOT NULL,
	precio DECIMAL(4,2) NOT NULL DEFAULT 0

);

CREATE TABLE TIENDA_VIDEOJUEGO (
    id_tienda INT,
    num_serie CHAR(9),    
	stock INT NOT NULL DEFAULT 0,
    
	
	CONSTRAINT FK_ID_TIENDA FOREIGN KEY (id_tienda) REFERENCES tienda (id) on delete CASCADE ,
	CONSTRAINT FK_NUMSERIE_TIENDA FOREIGN KEY (num_serie) REFERENCES videojuego (numero_serie) on delete CASCADE
	
	

);


create table cliente_videojuego (
	
	dni_cliente CHAR(9) not null,
    numero_serie CHAR(9) not null,
	precio DECIMAL(4,2),
    
	
	CONSTRAINT FK_DNI_CLIENTE FOREIGN KEY (dni_cliente) REFERENCES cliente (dni) on delete CASCADE ,
	CONSTRAINT FK_NUM_SERIE FOREIGN KEY (numero_Serie) REFERENCES videojuego (numero_serie) on delete CASCADE
	
	
	
	
  


);

 CREATE TABLE usuarios (
     dni CHAR(9) PRIMARY KEY,
     nombre VARCHAR(75)  ,
     password VARCHAR(75) ,
	 
	 
	 CONSTRAINT fk_dni_user FOREIGN KEY (dni) REFERENCES cliente(dni) on delete CASCADE
	 
	 
	);

INSERT INTO cliente (dni, nombre, apellidos, telefono, correo ) VALUES ('12312312A', 'Admin', ' ',  60000000, 'admin@tienda.com');
INSERT INTO usuarios (dni,nombre,password) VALUES ('12312312A','admin', '1234');

