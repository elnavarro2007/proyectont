package Vista;

import ControladorDAO.TiendaDAO;
import Modelo.Tienda;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazAñadirTienda extends JFrame {

    public InterfazAñadirTienda() {
        setTitle("añadir tienda");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        // Panel principal 3 filas, 2 columnas
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        JLabel nombreTienda = new JLabel("nombre tienda");
        JLabel telefono = new JLabel("telefono");
        JLabel ubicacion = new JLabel("ubicacion");
        JLabel correo = new JLabel("corrreo");
        JButton añadir = new JButton("añadir");
        JButton volver = new JButton("volver");

        JTextField escribirNombreTienda = new JTextField();
        JTextField escribirTelefono = new JTextField();
        JTextField escribirUbicacion = new JTextField();
        JTextField escribirCorreo = new JTextField();

        panel.add(nombreTienda);
        panel.add(escribirNombreTienda);
        panel.add(telefono);
        panel.add(escribirTelefono);
        panel.add(ubicacion);
        panel.add(escribirUbicacion);
        panel.add(correo);
        panel.add(escribirCorreo);
        panel.add(volver);
        panel.add(añadir);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTienda interfazGestionClientes = new InterfazGestionTienda();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = escribirNombreTienda.getText().trim();
                String telefono = escribirTelefono.getText().trim();
                String ubicacion = escribirUbicacion.getText();
                String correo = escribirCorreo.getText().trim();

                Tienda tienda = new Tienda(nombre, telefono, ubicacion, correo);

                if (!Validador.comprobarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "Nombre de la tienda no valido : Gama, Carrefive");
                    return;
                }
                if (!Validador.comprobarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "Telefono no valido, maximo 9 numeros, ejemplo: 671123123");
                    return;
                }
                if (!Validador.comprobarCorreo(correo)) {
                    JOptionPane.showMessageDialog(null, "correo no valido, ejemplo : ejemplo@gmail.com");
                    return;
                }
                if (!Validador.comprobarUbicacion(ubicacion)) {
                    JOptionPane.showMessageDialog(null, "Ubicacion no valida, ejemplo : Calle Sermon 23");
                    return;
                }


                try {
                    if (!Validador.comprobarNombre(nombre) || !Validador.comprobarCorreo(correo) || !Validador.comprobarTelefono(telefono) || !Validador.comprobarUbicacion(ubicacion)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el cliente, no se cumplen los requisitos");

                    } else {
                        TiendaDAO.insertarTienda(tienda);
                        JOptionPane.showMessageDialog(null, "Tienda añadida con exito");

                        escribirNombreTienda.setText("");
                        escribirUbicacion.setText("");
                        escribirCorreo.setText("");
                        escribirTelefono.setText("");
                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El correo debe ser unico.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }

            }
        });

    }

    static void main(String[] args) {
        InterfazAñadirTienda interfazAñadirTienda = new InterfazAñadirTienda();
        interfazAñadirTienda.setVisible(true);
    }
}
