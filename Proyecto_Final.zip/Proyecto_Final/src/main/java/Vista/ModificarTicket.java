package Vista;

import ControladorDAO.TicketCompraDAO;
import Modelo.TicketCompra;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarTicket extends JFrame {
    public ModificarTicket(TicketCompra ticketCompra) {
        setTitle("Modificar Ticket");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("ID COMPRA");
        JLabel numSerie = new JLabel(" numero_serie");
        JLabel precio = new JLabel("precio");
        JLabel nombre = new JLabel("nombre Juego");


        JTextField escribirID = new JTextField(ticketCompra.getDNI()); // parseo el id del ticket para que me lo pille
        escribirID.setEditable(false);
        JTextField escribirSerie = new JTextField(ticketCompra.getNumSerie());
        escribirSerie.setEditable(false);
        JTextField escribirNombre = new JTextField(ticketCompra.getNombre());
        escribirNombre.setEditable(false);
        JTextField escribirPrecio = new JTextField(ticketCompra.getPrecio());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(numSerie);
        panelModificar.add(escribirSerie);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(precio);
        panelModificar.add(escribirPrecio);


        //  panelModificar.add(passwd);

        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String dni = escribirID.getText().trim();
                String numero_serie = escribirSerie.getText().trim();
                String ticket = escribirPrecio.getText().trim();

                TicketCompra ticketCompra = new TicketCompra(dni, numero_serie, ticket);

                // Validadores

                if (!Validador.comprobarPrecio(ticket)) {
                    JOptionPane.showMessageDialog(null, "precio no valido : maximo 3 cifras y dos decimales");
                    return;
                }
                if (!Validador.comprobarNumSerie(numero_serie)) {
                    JOptionPane.showMessageDialog(null, "no se ha rellenado el campo o esta mal introducido, ejemplo : 12312312A");
                    return;
                }


                try {


                    if (!Validador.comprobarPrecio(ticket)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el cliente, no se cumplen los requisitos");

                    } else {
                        TicketCompraDAO.actualizarTicket(ticketCompra);
                        JOptionPane.showMessageDialog(null, "Videojuego añadido con exito");


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry")) {
                        JOptionPane.showMessageDialog(null, "El cliente no puede tener un ticket con el mismo dni y juego");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }

            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTicketsAdmin interfazVerTicketsAdmin = new InterfazVerTicketsAdmin();
                dispose();
            }
        });
    }
}
