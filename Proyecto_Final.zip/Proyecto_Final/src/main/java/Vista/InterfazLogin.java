package Vista;

import Configuracion.ArchivoLogin;
import ControladorDAO.UsuarioDAO;
import Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class InterfazLogin extends JFrame {

    public InterfazLogin() {
        // Configuración de la ventana
        setTitle("Inicio de Sesión");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Botones y y textos
        JLabel dni = new JLabel("Dni :");
        JTextField escribirDni = new JTextField();
        JLabel nombre = new JLabel("Nombre :");
        JTextField escribirNombre = new JTextField();
        JLabel password = new JLabel("Contraseña:");
        JPasswordField escrbirPassword = new JPasswordField(); // Este boton me permite que los caracteres se oculten cuando los pongo
        JButton loginButton = new JButton("Entrar");


        panel.add(dni);
        panel.add(escribirDni);
        panel.add(nombre);
        panel.add(escribirNombre);
        panel.add(password);
        panel.add(escrbirPassword);
        panel.add(new JLabel());
        panel.add(loginButton);

        add(panel);

        // Las acciones que hara cuando clickee el boton
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String obtenerDni = escribirDni.getText().trim();
                String usuarioNombre = escribirNombre.getText().trim();
                String getpassword = new String(escrbirPassword.getPassword()).trim();

                // Validación simple de ejemplo
                /*
                if (usuario.equals(TiendaDAO.iniciarCorreoTienda()) && password.equals(TiendaDAO.iniciarPasswdTienda())) {
                    JOptionPane.showMessageDialog(null, "¡Bienvenido al sistema!");
                } else {
                    JOptionPane.showMessageDialog(null, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
                }


                 */

                Usuario usuario = new Usuario(obtenerDni, usuarioNombre, getpassword);
                if (obtenerDni.isEmpty() && usuarioNombre.isEmpty() && getpassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "rellena los campos");
                } else if (obtenerDni.isEmpty() || usuarioNombre.isEmpty() || getpassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "rellena los campos faltantes");

                } else {


                    if (UsuarioDAO.compruebaUsuarioLogin(usuario)) {
                        JOptionPane.showMessageDialog(null, "Usuario Correcto");
                        dispose();
                        ArchivoLogin.registrarLogin(usuario);

                        if (obtenerDni.equals("12312312A")) {
                            InterfazDelAdmin gestion = new InterfazDelAdmin();
                            gestion.setVisible(true);
                        } else {
                            new InterfazDelCliente(usuario).setVisible(true);
                        }


                    } else {
                        JOptionPane.showMessageDialog(null, "Usuario o Contraseña incorrecto");
                        ArchivoLogin.registrarLogin(usuario);
                    }
                }
            }
        });

        // Agregar elementos al panel

    }

    static void main(String[] args) {
        // Para que pueda iniciar el programa desde el login

        new InterfazLogin().setVisible(true);

    }
}
