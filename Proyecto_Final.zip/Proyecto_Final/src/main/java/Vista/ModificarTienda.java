package Vista;

import ControladorDAO.TiendaDAO;
import Modelo.Tienda;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarTienda extends JFrame {
    public ModificarTienda(Tienda tienda) {

        setTitle("Modificar tiendas");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(6, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("id");
        JLabel nombre = new JLabel(" nombre");
        JLabel telefono = new JLabel("telefono");
        JLabel ubicacion = new JLabel("ubicacion");
        JLabel correo = new JLabel("Correo");


        JTextField escribirID = new JTextField(tienda.getId());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(tienda.getNombreTienda());
        JTextField escribirTelefono = new JTextField(tienda.getTelefono());
        JTextField escribirUbicacion = new JTextField(tienda.getUbicacion());
        JTextField escribirCorreo = new JTextField(tienda.getCorreo());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(telefono);
        panelModificar.add(escribirTelefono);
        panelModificar.add(ubicacion);
        panelModificar.add(escribirUbicacion);
        panelModificar.add(correo);
        panelModificar.add(escribirCorreo);

        //  panelModificar.add(passwd);

        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre = escribirNombre.getText().trim();
                String telefono = escribirTelefono.getText().trim();
                String ubicacion = escribirUbicacion.getText().trim();
                String correo = escribirCorreo.getText().trim();


                Tienda tiendas = new Tienda(nombre, telefono, ubicacion, correo, id);


                if (!Validador.comprobarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "Nombre de la tienda no valido : Gama, Carrefive");
                    return;
                }
                if (!Validador.comprobarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "Telefono no valido, maximo 9 numeros, ejemplo: 671123123");
                    return;
                }
                if (!Validador.comprobarCorreo(correo)) {
                    JOptionPane.showMessageDialog(null, "correo no valido, ejemplo : ejemplo@gmail.com");
                    return;
                }
                if (!Validador.comprobarUbicacion(ubicacion)) {
                    JOptionPane.showMessageDialog(null, "Ubicacion no valida, ejemplo : Calle Sermon 23");
                    return;
                }


                try {
                    if (!Validador.comprobarNombre(nombre) || !Validador.comprobarCorreo(correo) || !Validador.comprobarTelefono(telefono) || !Validador.comprobarUbicacion(ubicacion)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir la tienda, no se cumplen los requisitos");

                    } else {
                        TiendaDAO.actualizarTienda(tiendas);
                        JOptionPane.showMessageDialog(null, "Tienda modificada con exito");

                        escribirNombre.setText("");
                        escribirUbicacion.setText("");
                        escribirCorreo.setText("");
                        escribirTelefono.setText("");
                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El correo debe ser unico y no puede haber dos ID iguales.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTienda interfazVerTienda = new InterfazVerTienda();
                dispose();
            }
        });
    }
}
