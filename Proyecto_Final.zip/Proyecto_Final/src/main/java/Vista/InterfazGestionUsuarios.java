package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazGestionUsuarios extends JFrame {
    public InterfazGestionUsuarios() {

        setTitle(" Interfaz gestion Usuarios");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        // Panel principal 3 filas, 2 columnas
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JButton verUsuarios = new JButton("Ver, modificar y añadir Usuarios");
        JButton añadirUsuarios = new JButton("añadir Usuarios");
        JButton volver = new JButton("volver");

        panel.add(verUsuarios);
        panel.add(añadirUsuarios);

        panel.add(volver);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelAdmin interfazDelAdmin = new InterfazDelAdmin();
                dispose();
            }
        });
        añadirUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazSeleccionarClienteUsuario interfazSeleccionarClienteUsuario = new InterfazSeleccionarClienteUsuario();
                dispose();
            }
        });

        verUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerUsuarios interfazVerUsuarios = new InterfazVerUsuarios();
                dispose();
            }
        });
    }

    static void main(String[] args) {
        InterfazGestionUsuarios interfazGestionUsuarios = new InterfazGestionUsuarios();
        interfazGestionUsuarios.setVisible(true);
    }
}
