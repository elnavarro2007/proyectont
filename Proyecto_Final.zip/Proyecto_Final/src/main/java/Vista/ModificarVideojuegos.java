package Vista;

import ControladorDAO.VideojuegoDAO;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModificarVideojuegos extends JFrame {
    public ModificarVideojuegos(Videojuegos videojuegos) {

        setTitle("Modificar tiendas");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("numero serie");
        JLabel nombre = new JLabel("nombre");
        JLabel genero = new JLabel(" genero");

        JLabel precio = new JLabel("Precio");


        JTextField escribirID = new JTextField(videojuegos.getNumeroSerie());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(videojuegos.getNombre());
        JTextField escribirGenero = new JTextField(videojuegos.getGenero());

        JTextField escribirPrecio = new JTextField(videojuegos.getPrecio());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(genero);
        panelModificar.add(escribirGenero);
        panelModificar.add(precio);
        panelModificar.add(escribirPrecio);


        //  panelModificar.add(passwd);

        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre = escribirNombre.getText();
                String genero = escribirGenero.getText().trim();
                String precio = escribirPrecio.getText().trim();


                Videojuegos videojuegos1 = new Videojuegos(id, nombre, genero, precio);


                // Validadores
                if (!Validador.comprobarNombreVideojuego(nombre)) {
                    JOptionPane.showMessageDialog(null, " max 50 caracteres  Ejemplo : Persona 3 , Yakuza, Devil Survivor");
                    return;
                }
                if (!Validador.comprobarNumSerie(id)) {
                    JOptionPane.showMessageDialog(null, "el numero de serie es incorrecto ejemplo : 11037111Z");
                    return;
                }
                if (!Validador.comprobarGenero(genero)) {
                    JOptionPane.showMessageDialog(null, "Solo puedes introducir un genero por juego, ejemplo : RPG, Accion");
                    return;
                }
                if (!Validador.comprobarPrecio(precio)) {
                    JOptionPane.showMessageDialog(null, "precio no valido, ejemplo : 10.00 (el punto es importante)");
                    return;
                }


                try {


                    if (!Validador.comprobarNombreVideojuego(nombre) || !Validador.comprobarNumSerie(id) || !Validador.comprobarGenero(genero) || !Validador.comprobarPrecio(precio)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el juego, no se cumplen los requisitos");

                    } else {
                        VideojuegoDAO.actualizarVideojuego(videojuegos1);
                        JOptionPane.showMessageDialog(null, "Videojuego añadido con exito");


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry")) {
                        JOptionPane.showMessageDialog(null, "El número de serie ya existe y el nombre no puede repetirse");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerVideojuegos interfazVerVideojuegos = new InterfazVerVideojuegos();
                dispose();
            }
        });
    }
}
