package Vista;

import ControladorDAO.TicketCompraDAO;
import Modelo.Cliente;
import Modelo.TicketCompra;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazAñadirTicket extends JFrame {
    public InterfazAñadirTicket(Cliente cliente, Videojuegos videojuegos) {
        setTitle("Añadir Ticket");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel DNI = new JLabel("dni Cliente");
        JLabel num_serie = new JLabel("numero de serie");
        JLabel precio = new JLabel("precio");
        JTextField escribirDNi = new JTextField(cliente.getDni());
        escribirDNi.setEditable(false);
        JTextField escribirSerie = new JTextField(videojuegos.getNumeroSerie());
        escribirSerie.setEditable(false);
        JTextField escribirPrecio = new JTextField(videojuegos.getPrecio());

        JButton añadir = new JButton("añadir");
        JButton volver = new JButton("volver");

        panel.add(DNI);
        panel.add(escribirDNi);
        panel.add(num_serie);
        panel.add(escribirSerie);
        panel.add(precio);
        panel.add(escribirPrecio);
        panel.add(volver);
        panel.add(añadir);

        add(panel);
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTickets interfazGestionTickets = new InterfazGestionTickets();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dni = escribirDNi.getText().trim();
                String numero_serie = escribirSerie.getText().trim();
                String ticket = escribirPrecio.getText().trim();

                TicketCompra ticketCompra = new TicketCompra(dni, numero_serie, ticket);

                // Validadores

                if (!Validador.comprobarPrecio(ticket)) {
                    JOptionPane.showMessageDialog(null, "precio no valido : maximo 3 cifras y dos decimales");
                    return;
                }


                try {


                    if (!Validador.comprobarPrecio(ticket)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el cliente, no se cumplen los requisitos");

                    } else {
                        TicketCompraDAO.insertarCompra(ticketCompra);
                        JOptionPane.showMessageDialog(null, "Videojuego añadido con exito");


                        escribirPrecio.setText("");


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry")) {
                        JOptionPane.showMessageDialog(null, "El cliente no puede tener un ticket con el mismo dni y juego");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }

            }
        });


    }
}
