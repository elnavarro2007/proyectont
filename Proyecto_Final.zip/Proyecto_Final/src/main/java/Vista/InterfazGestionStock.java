package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazGestionStock extends JFrame {

    public InterfazGestionStock() {
        setTitle("Interfaz Gestion Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        // Panel principal 3 filas, 2 columnas
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JButton verStock = new JButton("ver,modificar y eliminar stock");
        JButton añadirStock = new JButton("añadir stock");

        JButton volver = new JButton("volver");

        panel.add(verStock);
        panel.add(añadirStock);

        panel.add(volver);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelAdmin interfazDelAdmin = new InterfazDelAdmin();
                dispose();
            }
        });
        añadirStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterFazSeleccionarTiendaStock interFazAñadirStock = new InterFazSeleccionarTiendaStock();
                dispose();


            }
        });

        verStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerStock interfazVerStock = new InterfazVerStock();
                dispose();
            }
        });


    }

    static void main() {
        InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
        interfazGestionStock.setVisible(true);
    }

    private void desactivarContenedor(java.awt.Container contenedor) {
        for (java.awt.Component comp : contenedor.getComponents()) {
            comp.setEnabled(false); // Desactiva clicks y escritura
            if (comp instanceof java.awt.Container) {
                desactivarContenedor((java.awt.Container) comp); // Aplica a paneles internos
            }
        }
    }
}
