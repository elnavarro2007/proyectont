package Vista;

import ControladorDAO.TiendaVideojuegoDAO;
import Modelo.Tienda;
import Modelo.TiendaVideojuegos;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazAñadirStock extends JFrame {
    public InterfazAñadirStock(Tienda tienda, Videojuegos videojuegos) {

        setTitle("Añadir Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel idTienda = new JLabel("id_tienda");
        JLabel num_serie = new JLabel("numero de serie");
        JLabel stock = new JLabel("stock");
        JTextField escribirid = new JTextField(tienda.getId());
        escribirid.setEditable(false);
        JTextField escribirserie = new JTextField(videojuegos.getNumeroSerie());
        escribirserie.setEditable(false);
        JTextField escribirstok = new JTextField();

        JButton añadir = new JButton("añadir");
        JButton volver = new JButton("volver");

        panel.add(idTienda);
        panel.add(escribirid);
        panel.add(num_serie);
        panel.add(escribirserie);
        panel.add(stock);
        panel.add(escribirstok);
        panel.add(volver);
        panel.add(añadir);

        add(panel);
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = escribirid.getText().trim();
                String numero_serie = escribirserie.getText().trim();
                String stock = escribirstok.getText().trim();

                TiendaVideojuegos tiendaVideojuegos = new TiendaVideojuegos(id, numero_serie, stock);

                if (!Validador.comprobarStock(stock)) {
                    JOptionPane.showMessageDialog(null, "Maximo 5 cifras sin decimales, si no pone nada, sera 0");
                    return;
                }


                try {
                    if (!Validador.comprobarStock(stock)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el stock");

                    } else {
                        TiendaVideojuegoDAO.insertarTiendaVideojuego(tiendaVideojuegos);
                        JOptionPane.showMessageDialog(null, "Stock añadido con exito");

                        escribirstok.setText("");

                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "No puede haber dos juegos en una misma tienda.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
    }

    static void main() {
        new InterfazAñadirStock(new Tienda(),new Videojuegos()).setVisible(true);
    }
}
