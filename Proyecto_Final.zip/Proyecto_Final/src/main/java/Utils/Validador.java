package Utils;

public class Validador {

    // Regex Clientes y alguno de tienda (nombre,telefono,correo)
    public static boolean comprobarNombre(String usuario) {
        return usuario.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ \\s]{2,30}$");
    }

    public static boolean comprobarDNI(String usuario) {
        return usuario.matches("^[0-9]{8}[A-Z]$");
    }

    public static boolean comprobarTelefono(String usuario) {
        return usuario.matches("^[0-9]{1}[0-9]{8}$");
    }

    public static boolean comprobarCorreo(String correo) {
        return correo.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean comprobarApellido(String usuario) {
        return usuario.matches("^[A-Za-zÁÉÍÓÚáéíóú]{2,25}$");
    }

    public static boolean comprobarUbicacion(String usuario) {
        return usuario.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ]{2,15}\\s[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ,ª\\s]{2,40}\\s[0-9]{1,3}$");
    }

    public static boolean comprobarNombreVideojuego(String usuario) {
        return usuario.matches("^[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ \\s]{2,50}$");
    }
    public static boolean comprobarNumSerie(String usuario) {
        return usuario.matches("^[0-9]{8}[A-Z]$");
    }
    public static boolean comprobarGenero(String usuario) {
        return usuario.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,20}$");
    }
    public static boolean comprobarPrecio(String usuario) {
        return usuario.matches("^[0-9]{1,3}+.[0-9]{1,2}$");
    }

    public static boolean comprobarStock(String usuario) {
        return usuario.matches("^[0-9]{1,5}$");
    }
    public static boolean comprobarNombreUsuario(String usuario) {
        return usuario.matches("^[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ]{2,50}$");
    }
    public static boolean comprobarPassword(String usuario) {
        return usuario.matches("^[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ]{8,50}$");
    }
    public static boolean comprobarNombreTienda(String usuario) {
        return usuario.matches("^[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ \\s]{2,30}$");
    }

 //
}
