package ControladorDAO;


import Modelo.TicketCompra;
import Modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static Configuracion.Conexion.getConnection;


public class TicketCompraDAO {

    public static boolean insertarCompra(TicketCompra ticket) {

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("Insert into cliente_videojuego (dni_cliente,numero_serie,precio) VALUES(?,?,?)")) {

            ps.setString(1, ticket.getDNI());
            ps.setString(2, ticket.getNumSerie());
            ps.setString(3, ticket.getPrecio());

            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static boolean eliminarCompra(TicketCompra ticket) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("Delete from cliente_videojuego where dni_cliente= ? and numero_serie= ?")) {

            ps.setString(1, ticket.getDNI());
            ps.setString(2, ticket.getNumSerie());

            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static ArrayList<TicketCompra> verTicket() {
        ArrayList<TicketCompra> ticket = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("SELECT cv.*,v.nombre,v.precio FROM cliente_videojuego cv join videojuego v on v.numero_serie = cv.numero_serie ")) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TicketCompra t = new TicketCompra();

                t.setDNI(rs.getString("dni_cliente"));
                t.setNumSerie(rs.getString("numero_serie"));
                t.setNombre(rs.getString("Nombre"));
                t.setPrecio(rs.getString("precio"));


                ticket.add(t);
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return ticket;
    }

    public static boolean actualizarTicket(TicketCompra ticket) {


        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("UPDATE cliente_videojuego SET numero_serie = ?, precio = ? WHERE dni_cliente = ? and numero_serie = ? ")) {


            ps.setString(1, ticket.getNumSerie());
            ps.setString(2, ticket.getPrecio());
            ps.setString(3, ticket.getDNI());
            ps.setString(4, ticket.getNumSerie());


            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar el cliente: " + e.getMessage(), e);
        }
    }

    public static ArrayList<TicketCompra> verTicketCliente(Usuario usuario) {
        ArrayList<TicketCompra> ticket = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("SELECT cv.*,v.nombre,v.precio FROM cliente_videojuego cv join videojuego v on v.numero_serie = cv.numero_serie where dni_cliente = ? ")) {


            ps.setString(1, usuario.getId());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TicketCompra t = new TicketCompra();

                t.setDNI(rs.getString("dni_cliente"));
                t.setNumSerie(rs.getString("numero_serie"));
                t.setNombre(rs.getString("Nombre"));
                t.setPrecio(rs.getString("precio"));


                ticket.add(t);
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return ticket;
    }
}
