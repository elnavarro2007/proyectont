package ControladorDAO;


import Modelo.TiendaVideojuegos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static Configuracion.Conexion.getConnection;


public class TiendaVideojuegoDAO {

    public TiendaVideojuegoDAO() {
    }

    // Funcion para insertar los datos en la tabla, si cumple con todos los valores del objeto y del insert, se insertaran en la tabla
    public static boolean insertarTiendaVideojuego(TiendaVideojuegos tiendaVideojuego) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("INSERT INTO tienda_videojuego (id_tienda,num_serie,stock) VALUES (?,?,?)")) {

            ps.setString(1, tiendaVideojuego.getId_tienda());
            ps.setString(2, tiendaVideojuego.getNum_serie());
            ps.setString(3, tiendaVideojuego.getStock());


            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean eliminarTiendaVideojuego(TiendaVideojuegos tiendaVideojuego) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("Delete from tienda_videojuego where id_tienda = ? and num_serie= ? ")) {

            ps.setString(1, tiendaVideojuego.getId_tienda());
            ps.setString(2, tiendaVideojuego.getNum_serie());


            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static ArrayList<TiendaVideojuegos> verStock() {
        ArrayList<TiendaVideojuegos> tiendaVideojuegos = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("select tv.id_tienda, t.nombre_tienda,tv.num_serie,v.nombre,tv.stock from tienda_Videojuego tv join tienda t on t.id = tv.id_tienda join videojuego v on v.numero_serie = tv.num_serie; ")) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TiendaVideojuegos tv = new TiendaVideojuegos();

                tv.setId_tienda(rs.getString("id_tienda"));
                tv.setNombreTienda(rs.getString("nombre_tienda"));
                tv.setNum_serie(rs.getString("num_serie"));
                tv.setNombreVIdeojuego(rs.getString("nombre"));
                tv.setStock(rs.getString("stock"));


                tiendaVideojuegos.add(tv);
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return tiendaVideojuegos;
    }


    public static boolean modificarStock(TiendaVideojuegos tiendaVideojuegos) {


        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("UPDATE tienda_videojuego SET num_serie = ?, stock = ? WHERE id_tienda = ?")) {


            ps.setString(1, tiendaVideojuegos.getNum_serie());
            ps.setString(2, tiendaVideojuegos.getStock());
            ps.setString(3, tiendaVideojuegos.getId_tienda());


            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar el cliente: " + e.getMessage(), e);
        }
    }

    public static boolean existeJuegoEnTienda(String idTienda, String numeroSerie) {
        String sql = "SELECT COUNT(*) FROM tienda_videojuego WHERE id_tienda = ? AND num_serie = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, idTienda);
            ps.setString(2, numeroSerie);

            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        }  catch (SQLException e) {
            throw new RuntimeException("Error al actualizar el cliente: " + e.getMessage(), e);
        }



    }
}
