package Configuracion;

import ControladorDAO.UsuarioDAO;
import Modelo.Usuario;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ArchivoLogin {

    private static final String CARPETA = "logs";
    private static final String ARCHIVO = "logs/login.log";

    public static void registrarLogin(Usuario usuario) {

        try {

            File dir = new File(CARPETA);
            if (!dir.exists()) {
                System.out.println("Creado con exito");
                dir.mkdir();
            }

            FileWriter writer = new FileWriter(ARCHIVO, true);

            LocalDateTime fechaHora = LocalDateTime.now();
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


            if (UsuarioDAO.comprobarUserRegistro(usuario)) {
                String linea = fechaHora.format(formato)
                        + " | Usuario: " + usuario.getNombre()
                        + " | DNI : "+usuario.getId()
                        + " | Passowrd : "+usuario.getPassword()
                        + " | Resultado: " + "Logeado correctamente";


                writer.write(linea);
                writer.close();
            } else {
                String linea = fechaHora.format(formato)
                        + " | Usuario: " + usuario.getNombre()
                        + " | DNI : "+usuario.getId()
                        + " | Passowrd : "+usuario.getPassword()
                        + " | Resultado: " + "Logeo Incorrecto";


                writer.write(linea);
                writer.close();
            }


        } catch (IOException e) {
            System.err.println("Error escribiendo el log de login");
            e.printStackTrace();
        }
    }
}
