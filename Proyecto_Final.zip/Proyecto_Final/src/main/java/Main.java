//package org.example;
//
//import org.example.Vista.InterfazDelAdmin;
//import org.example.Vista.InterfazLogin;
//
////TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
//// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
//public class Main {
//    public static void main(String[] args) {
//
//        new InterfazDelAdmin().setVisible(true);
//
//    }
//}