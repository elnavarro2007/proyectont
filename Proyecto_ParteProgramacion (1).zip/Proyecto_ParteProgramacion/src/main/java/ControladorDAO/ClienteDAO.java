package ControladorDAO;


import Modelo.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static Configuracion.Conexion.getConnection;


public class ClienteDAO {
    // hacer un login para clientes para que puedan ver solo sus tickets


    public ClienteDAO() {

    }

    // Funcion para insertar los datos en la tabla, si cumple con todos los valores del objeto y del insert, se insertaran en la tabla
    public static boolean insertarCliente(Cliente cliente) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("INSERT INTO cliente (dni,nombre,apellidos,telefono,correo) VALUES (?,?,?,?,?)")) {

            ps.setString(1, cliente.getDni());
            ps.setString(2, cliente.getNombre());
            ps.setString(3, cliente.getApellidos());
            ps.setString(4, cliente.getTelefono());
            ps.setString(5, cliente.getCorreo());

            int filasAfectadas = ps.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean eliminarCliente(Cliente cliente) {
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("Delete from cliente where dni= ? ")) {

            ps.setString(1, cliente.getDni());


            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public static ArrayList<Cliente> verCliente() {
        ArrayList<Cliente> clientes = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("SELECT * FROM cliente where dni != '12312312A' order by nombre asc")) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();

                c.setDni(rs.getString("dni"));
                c.setNombre(rs.getString("nombre"));
                c.setApellidos(rs.getString("apellidos"));
                c.setTelefono(rs.getString("telefono"));
                c.setCorreo(rs.getString("correo"));

                clientes.add(c);
            }



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return clientes;

    }
    public static boolean actualizarCliente(Cliente cliente){


        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("UPDATE cliente SET nombre = ?,apellidos = ?, telefono = ?, correo = ? WHERE dni = ?")) {


            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellidos());
            ps.setString(3,cliente.getTelefono());
            ps.setString(4,cliente.getCorreo());
            ps.setString(5,cliente.getDni());

            int columnasAfectadas = ps.executeUpdate();
            return columnasAfectadas > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar el cliente: " + e.getMessage(), e);
        }
    }

    public static ArrayList<Cliente> verClientesSinUsuario() {
        ArrayList<Cliente> clientes = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement("SELECT * FROM cliente c where dni != '12312312A'  and \n" +
                     "not exists (select dni from usuarios u where u.dni = c.dni )order by nombre asc;")) {

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();

                c.setDni(rs.getString("dni"));
                c.setNombre(rs.getString("nombre"));
                c.setApellidos(rs.getString("apellidos"));
                c.setTelefono(rs.getString("telefono"));
                c.setCorreo(rs.getString("correo"));

                clientes.add(c);
            }



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return clientes;

    }


}
