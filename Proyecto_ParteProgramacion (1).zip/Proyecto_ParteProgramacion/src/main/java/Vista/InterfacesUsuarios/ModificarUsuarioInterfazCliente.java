package Vista.InterfacesUsuarios;

import ControladorDAO.UsuarioDAO;
import Modelo.Usuario;
import Utils.Validador;
import Vista.InterfazDelCliente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ModificarUsuarioInterfazCliente extends JFrame {
    Usuario user;

    public ModificarUsuarioInterfazCliente(Usuario usuario) {
        this.user = usuario;
        setTitle("Cliente modificando su usuario");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("dni");
        JLabel nombre = new JLabel(" nombre");
        JLabel password = new JLabel("nueva password");


        JTextField escribirID = new JTextField(usuario.getId());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(usuario.getNombre());

        JTextField escribirPassword = new JTextField();



        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(password);
        panelModificar.add(escribirPassword);
        panelModificar.add(new JLabel());
        panelModificar.add(new JLabel());



        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre = escribirNombre.getText().trim();
                String passwd = escribirPassword.getText().trim();

                Usuario usuario1 = new Usuario(id, nombre, passwd);

                if (!Validador.comprobarNombreUsuario(nombre)) {
                    JOptionPane.showMessageDialog(null, "Solo caracteres del abecedario y numeros, nombre entre 4 y 20 y numeros caracteres Ejemplo : nAvarro07");
                    return;
                }

                if (!Validador.comprobarPassword(passwd)) {
                    JOptionPane.showMessageDialog(null, "La contraseña debe tener minimo 8 caracteres y maximo 50,solo numeros y letras, ejemplo : Dam12345");
                    return;
                }




                try {
                    if (!Validador.comprobarNombreUsuario(nombre) ||  !Validador.comprobarPassword(passwd)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el usuario, no se cumplen los requisitos");

                    } else {
                        UsuarioDAO.actualizarUsuario(usuario1);
                        JOptionPane.showMessageDialog(null, "Usuario modificado con exito");
                        dispose();
                        new InterfazDelCliente(usuario).setVisible(true);


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "No pueden existir dos usernames iguales aunque se diferencien en mayusculas y minusculas");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelCliente interfazDelCliente = new InterfazDelCliente(usuario);
                dispose();
            }
        });


        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }


}
