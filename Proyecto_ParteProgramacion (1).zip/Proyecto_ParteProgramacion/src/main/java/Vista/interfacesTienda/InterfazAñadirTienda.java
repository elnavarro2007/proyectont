package Vista.interfacesTienda;

import ControladorDAO.TiendaDAO;
import Modelo.Tienda;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
/*Introduzco todos los valores, se los paso a un objeto con todos los parametros
 * los paso por unos validadores para que verifique
 * todo, si se cumple todos los requisitos, se añade el objeto a la base de datos*/
public class InterfazAñadirTienda extends JFrame {

    public InterfazAñadirTienda() {
        setTitle("añadir tienda");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        //
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        JLabel nombreTienda = new JLabel("nombre tienda");
        JLabel telefono = new JLabel("telefono");
        JLabel ubicacion = new JLabel("ubicacion");
        JLabel correo = new JLabel("corrreo");
        JButton añadir = new JButton("añadir");
        JButton volver = new JButton("volver");

        JTextField escribirNombreTienda = new JTextField();
        JTextField escribirTelefono = new JTextField();
        JTextField escribirUbicacion = new JTextField();
        JTextField escribirCorreo = new JTextField();

        panel.add(nombreTienda);
        panel.add(escribirNombreTienda);
        panel.add(telefono);
        panel.add(escribirTelefono);
        panel.add(ubicacion);
        panel.add(escribirUbicacion);
        panel.add(correo);
        panel.add(escribirCorreo);
        panel.add(volver);
        panel.add(añadir);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTienda interfazGestionClientes = new InterfazGestionTienda();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = escribirNombreTienda.getText().trim();
                String telefono = escribirTelefono.getText().trim();
                String ubicacion = escribirUbicacion.getText();
                String correo = escribirCorreo.getText().trim();

                Tienda tienda = new Tienda(nombre, telefono, ubicacion, correo);

                if(nombre.isEmpty() || telefono.isEmpty() || ubicacion.isEmpty() ||correo.isEmpty()){
                    JOptionPane.showMessageDialog(null, " Rellna todos los campos");
                    return;
                }

                if (!Validador.comprobarNombreTienda(nombre)) {
                    JOptionPane.showMessageDialog(null, "Nombre de la tienda no valido , max 40 caracteres, ejemplos: Games, Carrefour's");
                    return;
                }
                if (!Validador.comprobarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "Telefono no valido, maximo 9 numeros, ejemplo: 671123123");
                    return;
                }
                if (!Validador.comprobarCorreo(correo)) {
                    JOptionPane.showMessageDialog(null, "correo no valido, max 150 caracteres,ejemplo : ejemplo@gmail.com");
                    return;
                }
                if (!Validador.comprobarUbicacion(ubicacion)) {
                    JOptionPane.showMessageDialog(null, "Ubicacion no valida, max 100 caracteres,ejemplo : Calle Sermon 23, Teruel (ha de seguir ese formato)");
                    return;
                }


                try {
                    if (!Validador.comprobarNombreTienda(nombre) || !Validador.comprobarCorreo(correo) || !Validador.comprobarTelefono(telefono) || !Validador.comprobarUbicacion(ubicacion)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir la tienda, no se cumplen los requisitos");

                    } else {
                        TiendaDAO.insertarTienda(tienda);
                        JOptionPane.showMessageDialog(null, "Tienda añadida con exito");
                        dispose();
                        new InterfazGestionTienda();


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El correo debe ser unico.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }

            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }


}
