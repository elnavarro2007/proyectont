package Vista.interfacesTienda;

import ControladorDAO.TiendaDAO;
import Modelo.Tienda;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class InterfazVerTienda extends JFrame {

    /*Pasos que hago :
    * Añado los atributos para que ninguna clase pueda acceder a otras
    * Defino los ajustes de la interfaz
    * Le dijo a tiendas de donde debe obtener los datos de las tablas
    * Defino las columnas de la interfaz y las añado a la tabla tienda
    * hago el foreach para ir obteniendo los datos de la tabla
    * hago que solo pueda seleccionarse un dato a la vez
    * defino una variable que al clickar en ella obtenga sus datos
    * en los diferentes botones cada uno hara su accion correspondiente
    * */
    private JTable tablaTienda;
    private DefaultTableModel modeloTabla;
    private ArrayList<Tienda> tiendas; // Para enlazar la fila seleccionada con el objeto real

    public InterfazVerTienda() {
        setTitle("Ver Tiendas");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton actualizar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");


        tiendas = TiendaDAO.verTienda();


        String[] columnas = { "Tienda","Telefono", "Ubicacion","correo"};

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Las celdas son de solo lectura
            }
        };


        for (Tienda t : tiendas) {
            Object[] fila = { t.getNombreTienda(), t.getTelefono(),t.getUbicacion(),t.getCorreo()};
            modeloTabla.addRow(fila);
        }

        tablaTienda = new JTable(modeloTabla);
        tablaTienda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tablaTienda);
        scroll.setPreferredSize(new Dimension(600, 350));

        panelBotones.add(volver);
        panelBotones.add(actualizar);
        panelBotones.add(eliminar);

        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);

        // Listeners

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new InterfazGestionTienda();
                dispose();
            }
        });

        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaTienda.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado ninguna tienda");
                } else {
                    Tienda seleccionado = tiendas.get(filaSeleccionada);

                    int respuesta = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar la tienda? si hay stock en esta tienda, se eliminara todo lo relacionado de la tienda.",
                            "Eliminar", JOptionPane.YES_NO_OPTION);

                    if (respuesta == JOptionPane.YES_OPTION) {
                        boolean eliminado = TiendaDAO.eliminarTienda(seleccionado);
                        JOptionPane.showMessageDialog(null, "Eliminado con éxito");
                        dispose();
                        new InterfazVerTienda(); // Recarga la interfaz limpia
                    }
                }
            }
        });

        actualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el índice de la fila que el usuario seleccionó
                int filaSeleccionada = tablaTienda.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "Tienda no seleccionada");
                } else {
                    // Con el índice obtenemos el objeto completo con su ID interno o CIF listo
                    Tienda seleccionado = tiendas.get(filaSeleccionada);

                    new ModificarTienda(seleccionado); // Pasamos la tienda completa con sus identificadores
                    dispose();
                }
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });





    }


}
