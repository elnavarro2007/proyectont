package Vista.InterfacesSeleccion;

import ControladorDAO.TiendaDAO;
import Modelo.Tienda;
import Vista.InterfacesStock.InterfazGestionStock;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class InterFazSeleccionarTiendaStock extends JFrame {

    private JTable tablaTiendas;
    private DefaultTableModel modeloTabla;
    private ArrayList<Tienda> tiendas;
    /*Pasos que hago :
     * Añado los atributos para que ninguna clase pueda acceder a otras
     * Defino los ajustes de la interfaz
     * Le dijo a tiendas de donde debe obtener los datos de las tablas
     * Defino las columnas de la interfaz y las añado a la tabla tienda
     * hago el foreach para ir obteniendo los datos de la tabla
     * hago que solo pueda seleccionarse un dato a la vez
     * defino una variable que al clickar en ella obtenga sus datos
     * en los diferentes botones cada uno hara su accion correspondiente
     * */
    public InterFazSeleccionarTiendaStock() {
        setTitle("seleccionar Tienda");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");

        tiendas = TiendaDAO.verTienda();

        String[] columnas = { "Nombre de Tienda", "telefono", "Ubicacion","correo"};

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Tienda t : tiendas) {
            Object[] fila = { t.getNombreTienda(), t.getTelefono(),t.getUbicacion(),t.getCorreo()};
            modeloTabla.addRow(fila);
        }

        tablaTiendas = new JTable(modeloTabla);
        tablaTiendas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tablaTiendas);
        scroll.setPreferredSize(new Dimension(600, 350));

        panelBotones.add(volver);
        panelBotones.add(seleccionar);

        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                dispose();
            }
        });

        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaTiendas.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "Tienda no seleccionada");
                } else {
                    Tienda seleccionada = tiendas.get(filaSeleccionada);
                    InterfazSeleccionarStockVideojuego interfazAñadirStockVideojuego = new InterfazSeleccionarStockVideojuego(seleccionada);
                    dispose();
                }
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });


    }


}
