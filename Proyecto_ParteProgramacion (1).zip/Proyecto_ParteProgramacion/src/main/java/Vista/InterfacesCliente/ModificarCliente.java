package Vista.InterfacesCliente;

import ControladorDAO.ClienteDAO;
import Modelo.Cliente;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
/*Pasos que realizo :
 * Pillo el objeto de la interfaz anterior para pasarlo a esta nueva,
 * obtengo sus atributos y hago que se puedan modificar solo los necesarios*/
public class ModificarCliente extends JFrame {


    public ModificarCliente(Cliente cliente) {
        setTitle("Modificar Cliente");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel DNI = new JLabel("DNI");
        JLabel nombre = new JLabel("nombre");
        JLabel apellido = new JLabel("apellido");
        JLabel telefono = new JLabel("telefono");
        JLabel correo = new JLabel("correo");


        JTextField escribirDNi = new JTextField(cliente.getDni());
        escribirDNi.setEditable(false);
        JTextField escribirNombre = new JTextField(cliente.getNombre());
        JTextField escribirAPellido = new JTextField(cliente.getApellidos());
        JTextField escribirTelefono = new JTextField(cliente.getTelefono());
        JTextField escribirCorreo = new JTextField(cliente.getCorreo());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panel.add(DNI);
        panel.add(escribirDNi);
        panel.add(nombre);
        panel.add(escribirNombre);
        panel.add(apellido);
        panel.add(escribirAPellido);
        panel.add(telefono);
        panel.add(escribirTelefono);
        panel.add(correo);
        panel.add(escribirCorreo);

        panel.add(volver);
        panel.add(modificar);

        add(panel);

        // Botones
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerCliente interfazVerCliente = new InterfazVerCliente();
                dispose();
            }
        });
        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dni = escribirDNi.getText().trim();
                String nombre = escribirNombre.getText().trim();
                String apellido = escribirAPellido.getText().trim();
                String telefono = escribirTelefono.getText().trim();
                String correo = escribirCorreo.getText().trim();


                Cliente cliente = new Cliente(dni, nombre, apellido, telefono, correo);

                if ( nombre.isEmpty() || apellido.isEmpty() || telefono.isEmpty() || correo.isEmpty()) {

                    JOptionPane.showMessageDialog(null, " Rellena todos los campos");
                    return;

                }

                // Validadores
                if (!Validador.comprobarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "Solo caracteres del abecedario, max 30 caracteres y primera en mayuscula Ejemplo : Diego, Lucía");
                    return;
                }
                if (!Validador.comprobarDNI(dni)) {
                    JOptionPane.showMessageDialog(null, "el dni es incorrecto, max 9 caracteres ejemplo : 11037111Z");
                    return;
                }
                if (!Validador.comprobarApellido(apellido)) {
                    JOptionPane.showMessageDialog(null, "Debe haber SOLO un apellido, y la primera en mayuscula con un maximo 30 caracteres ej : Navarro");
                    return;
                }
                if (!Validador.comprobarCorreo(correo)) {
                    JOptionPane.showMessageDialog(null, "correo no valido, max 150 caracteres,ejemplo : ejemplo@gmail.com");
                    return;
                }
                if (!Validador.comprobarTelefono(telefono)) {
                    JOptionPane.showMessageDialog(null, "Telefono no valido, maximo 9 numeros, ejemplo: 671123123");
                    return;
                }

                try {
                    if (!Validador.comprobarNombre(nombre) || !Validador.comprobarDNI(dni) || !Validador.comprobarApellido(apellido) || !Validador.comprobarCorreo(correo) || !Validador.comprobarTelefono(telefono)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el cliente, no se cumplen los requisitos");

                    } else {
                        ClienteDAO.actualizarCliente(cliente);
                        JOptionPane.showMessageDialog(null, "cliente modificado con exito");
                        dispose();
                        new InterfazVerCliente().setVisible(true);

                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El dni ya existe, el correo debe ser unico.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }



}
