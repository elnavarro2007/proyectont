package Vista;

import Modelo.Usuario;
import Vista.InterfacesTickets.InterfazVerTicketCliente;
import Vista.InterfacesUsuarios.ModificarUsuarioInterfazCliente;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfazDelCliente extends JFrame {
    Usuario user;

    public InterfazDelCliente(Usuario usuario) {
        this.user = usuario;


        setTitle("interfaz Cliente");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setVisible(true);
        setResizable(false);

        JButton botonTicket = new JButton("Ver Tickets");
        JButton botonModificarUsuario = new JButton("Modificar usuario");
        JButton botonCerrarSesion = new JButton("Cerrar sesion");


        panel.add(botonTicket);
        panel.add(botonModificarUsuario);
        panel.add(botonCerrarSesion);

        add(panel);

        botonTicket.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTicketCliente interfazVerTicketCliente = new InterfazVerTicketCliente(usuario);
                dispose();
            }
        });

        botonModificarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ModificarUsuarioInterfazCliente modificarUsuarioInterfazCliente = new ModificarUsuarioInterfazCliente(usuario);
                dispose();
            }
        });
        botonCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null, "Cerrar sesion?", "Cerrar Sesion", JOptionPane.YES_NO_OPTION);
                if (respuesta == JOptionPane.YES_OPTION) {

                    dispose();
                    new InterfazLogin().setVisible(true);

                }
                if (respuesta == JOptionPane.NO_OPTION) {

                }
            }
        });


        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });


    }

     static void main(String[] args) {
        new InterfazDelCliente(new Usuario()).setVisible(true);
    }
}
