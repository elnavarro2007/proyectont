package Vista.InterfacesVideojuegos;


import ControladorDAO.VideojuegoDAO;

import Modelo.Videojuegos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
/*Pasos que hago :
 * Añado los atributos para que ninguna clase pueda acceder a otras
 * Defino los ajustes de la interfaz
 * Le dijo a tiendas de donde debe obtener los datos de las tablas
 * Defino las columnas de la interfaz y las añado a la tabla tienda
 * hago el foreach para ir obteniendo los datos de la tabla
 * hago que solo pueda seleccionarse un dato a la vez
 * defino una variable que al clickar en ella obtenga sus datos
 * en los diferentes botones cada uno hara su accion correspondiente
 * */
public class InterfazVerVideojuegos extends JFrame {

    private JTable tablaVideojuegos;
    private DefaultTableModel modeloTabla;
    private ArrayList<Videojuegos> videojuegos; // Guardamos la lista para relacionar el índice de la tabla

    public InterfazVerVideojuegos() {
        setTitle("Ver Videojuegos");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("Volver");
        JButton actualizar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");

        videojuegos = VideojuegoDAO.verVideojuegos();

        String[] columnas = {"numSerie", "Nombre", "genero", "precio"};

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // sirve para que no pueda editar las tablas
            }
        };

        for (Videojuegos v : videojuegos) {
            Object[] fila = {v.getNumeroSerie(), v.getNombre(), v.getGenero(), v.getPrecio() + "€"};
            modeloTabla.addRow(fila);
        }

        tablaVideojuegos = new JTable(modeloTabla);
        tablaVideojuegos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tablaVideojuegos);
        scroll.setPreferredSize(new Dimension(600, 350));

        panelBotones.add(volver);
        panelBotones.add(actualizar);
        panelBotones.add(eliminar);

        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);


        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new InterfazGestionVideojuegos();
                dispose();
            }
        });

        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada de la tabla
                int filaSeleccionada = tablaVideojuegos.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado ningun videojuego");
                } else {
                    Videojuegos seleccionado = videojuegos.get(filaSeleccionada);

                    int respuesta = JOptionPane.showConfirmDialog(null,
                            "Seguro que quieres eliminar el videojuego? Se eliminarán sus tickets correspondientes.",
                            "Confirmar eliminacion", JOptionPane.YES_NO_OPTION);

                    if (respuesta == JOptionPane.YES_OPTION) {
                        boolean eliminado = VideojuegoDAO.eliminarVideojuego(seleccionado);
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                        dispose();
                        new InterfazVerVideojuegos();
                    }else {

                    }
                }
            }
        });

        actualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada de la tabla
                int filaSeleccionada = tablaVideojuegos.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "Videojuego no seleccionado");
                } else {
                    // Así solucionas lo que le ibas a preguntar a Ángel: el objeto "seleccionado"
                    Videojuegos seleccionado = videojuegos.get(filaSeleccionada);

                    new ModificarVideojuegos(seleccionado); // Le pasas el cliente completo con su DNI
                    dispose();
                }
            }
        });


        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });





    }


}

