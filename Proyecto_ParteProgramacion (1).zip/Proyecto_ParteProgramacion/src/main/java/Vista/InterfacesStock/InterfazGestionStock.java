package Vista.InterfacesStock;

import Vista.InterfacesSeleccion.InterFazSeleccionarTiendaStock;
import Vista.InterfazDelAdmin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfazGestionStock extends JFrame {

    public InterfazGestionStock() {
        setTitle("Interfaz Gestion Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JButton verStock = new JButton("ver,modificar y eliminar stock");
        JButton añadirStock = new JButton("añadir stock");

        JButton volver = new JButton("volver");



        panel.add(verStock);
        panel.add(añadirStock);

        panel.add(volver);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelAdmin interfazDelAdmin = new InterfazDelAdmin();
                dispose();
            }
        });
        añadirStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterFazSeleccionarTiendaStock interFazAñadirStock = new InterFazSeleccionarTiendaStock();
                dispose();


            }
        });

        verStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerStock interfazVerStock = new InterfazVerStock();
                dispose();
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });





    }




}
