package Vista.InterfacesStock;

import ControladorDAO.TiendaVideojuegoDAO;
import Modelo.TiendaVideojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*Pasos que realizo :
* Pillo el objeto de la interfaz anterior para pasarlo a esta nueva,
* obtengo sus atributos y hago que se puedan modificar solo los necesarios*/

public class ModificarStock extends JFrame {
    public ModificarStock(TiendaVideojuegos tiendaVideojuegos) {
        setTitle("Modificar Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(6, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel(" id_tienda");
        JLabel numSerie = new JLabel("numero Serie");
        JLabel stock = new JLabel("Stock");
        JLabel tienda = new JLabel("nombre tienda");
        JLabel juego = new JLabel("nombre juego");





        JTextField escribirID = new JTextField(tiendaVideojuegos.getId_tienda());
        escribirID.setEditable(false);
        JTextField escribirTienda = new JTextField(tiendaVideojuegos.getNombreTienda());
        escribirTienda.setEditable(false);
        JTextField escribiSerie = new JTextField(tiendaVideojuegos.getNum_serie());
        escribiSerie.setEditable(false);
        JTextField escribirJuego = new JTextField(tiendaVideojuegos.getNombreVIdeojuego());
        escribirJuego.setEditable(false);
        JTextField escribirStock = new JTextField(tiendaVideojuegos.getStock());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(tienda);
        panelModificar.add(escribirTienda);
        panelModificar.add(numSerie);
        panelModificar.add(escribiSerie);
        panelModificar.add(juego);
        panelModificar.add(escribirJuego);
        panelModificar.add(stock);
        panelModificar.add(escribirStock);
        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText().trim();
                String numSerie = escribiSerie.getText().trim();
                String stock = escribirStock.getText().trim();


                TiendaVideojuegos tiendaVideojuegos1 = new TiendaVideojuegos(id, numSerie, stock);





                try {
                    if (!Validador.comprobarStock(stock)) {
                        JOptionPane.showMessageDialog(null, "Maximo 5 cifras sin decimales, si no pones nada, sera 0");
                        return;
                    } else {
                        TiendaVideojuegoDAO.modificarStock(tiendaVideojuegos1);
                        JOptionPane.showMessageDialog(null, "Stock añadido con exito");
                        new InterfazVerStock().setVisible(true);
                        dispose();


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "No puede haber dos juegos iguales en una misma tienda.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerStock interfazVerStock = new InterfazVerStock();
                dispose();
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });


    }

}
