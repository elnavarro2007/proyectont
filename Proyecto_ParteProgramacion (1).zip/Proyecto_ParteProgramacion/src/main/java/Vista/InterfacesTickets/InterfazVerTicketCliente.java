package Vista.InterfacesTickets;

import ControladorDAO.TicketCompraDAO;
import Modelo.TicketCompra;
import Modelo.Usuario;
import Vista.InterfazDelCliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
/*Pasos que hago :
 * Añado los atributos para que ninguna clase pueda acceder a otras
 * Defino los ajustes de la interfaz
 * Le dijo a tiendas de donde debe obtener los datos de las tablas
 * Defino las columnas de la interfaz y las añado a la tabla tienda
 * hago el foreach para ir obteniendo los datos de la tabla
 * hago que solo pueda seleccionarse un dato a la vez
 * defino una variable que al clickar en ella obtenga sus datos
 * en los diferentes botones cada uno hara su accion correspondiente,
 * en este caso tendre que pasarle el objeto usuario cuando inicio sesion
 * */
public class InterfazVerTicketCliente extends JFrame {
    Usuario user;
    private JTable tablaTicketCliente;
    private DefaultTableModel modeloTabla;
    private ArrayList<TicketCompra> ticketCliente;

    public InterfazVerTicketCliente(Usuario usuario) {

        this.user = usuario;
        setTitle("Ventana para que el usuario logeado vea los tickets ");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);



        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("Volver");


        ticketCliente = TicketCompraDAO.verTicketCliente(usuario);




        String[] columnas = {"DNI", "Numero Serie", "Juego", "precio"};

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Las celdas no son editables directamente
            }
        };

        for (TicketCompra t : ticketCliente) {
            Object[] fila = {t.getDNI(), t.getNumSerie(), t.getNombre(),  t.getPrecio()};
            modeloTabla.addRow(fila);
        }

        tablaTicketCliente = new JTable(modeloTabla);
        tablaTicketCliente.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tablaTicketCliente);
        scroll.setPreferredSize(new Dimension(600, 350));

        panelBotones.add(volver);


        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);

        // Listeners

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new InterfazDelCliente(usuario);
                dispose();
            }
        });
        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });




    }


}
