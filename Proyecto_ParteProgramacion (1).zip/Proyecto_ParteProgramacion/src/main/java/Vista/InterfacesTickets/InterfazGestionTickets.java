package Vista.InterfacesTickets;

import Vista.InterfacesCliente.InterfazGestionClientes;
import Vista.InterfazDelAdmin;
import Vista.InterfacesSeleccion.InterfazSeleccionarStockTicket;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfazGestionTickets extends JFrame {

    public InterfazGestionTickets() {
        setTitle("Gestion De Tickets");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setVisible(true);
        setResizable(false);

        JButton verTickets = new JButton("Ver, modificar y eliminar Tickets");
        JButton añadirTickets = new JButton(" Hacer compra");
        JButton volver = new JButton("volver");

        panel.add(verTickets);
        panel.add(añadirTickets);
        panel.add(volver);

        add(panel);


        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazDelAdmin interfazDelAdmin = new InterfazDelAdmin();
                dispose();
            }
        });
        añadirTickets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 new InterfazSeleccionarStockTicket();
                dispose();
            }
        });
        verTickets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerTicketsAdmin interfazVerTicketsAdmin = new InterfazVerTicketsAdmin();
                dispose();
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

    }


}
