package Vista.InterfacesTickets;

import ControladorDAO.TicketCompraDAO;
import ControladorDAO.TiendaVideojuegoDAO;
import ControladorDAO.VideojuegoDAO;
import Modelo.Cliente;
import Modelo.TiendaVideojuegos; // Cambiado a TiendaVideojuegos
import Modelo.TicketCompra;       // Asumiendo que tienes este modelo para construir el objeto
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
/*Introduzco todos los valores, se los paso a un objeto con todos los parametros
 * los paso por unos validadores para que verifique
 * todo, si se cumple todos los requisitos, se añade el objeto a la base de datos*/


/*En esta interfaz le paso los objetos seleccionados de las interfaces anteriores,
* le paso el objeto videojuego para hacer el dao de numeroserie del numero de serie del juego de la tienda
* seleccionado para asi obtener el precio de ese juego */
public class InterfazAñadirTicket extends JFrame {

    // El constructor recibe Cliente y el Stock de la tienda
    public InterfazAñadirTicket(Cliente cliente, TiendaVideojuegos juegoTienda) {

        // busco el id del juego por el id del numero de serie de la tienda seleccionada
        Videojuegos v = VideojuegoDAO.buscarPorNumeroSerie(juegoTienda.getNum_serie());




        setTitle("Añadir Ticket");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblDni = new JLabel("DNI Cliente:");
        JTextField escribirDNi = new JTextField(cliente.getDni());
        escribirDNi.setEditable(false);

        JLabel lblSerie = new JLabel("Número de Serie (Juego):");

        JTextField escribirSerie = new JTextField(String.valueOf(juegoTienda.getNum_serie()));
        escribirSerie.setEditable(false);


        JLabel lblPrecio = new JLabel("Precio:");
        JTextField escribirPrecio = new JTextField(v.getPrecio());
        escribirPrecio.setEditable(false);

        JButton cancelar = new JButton("Cancelar");
        JButton guardar = new JButton("Guardar Ticket");

        // Añadir componentes al panel
        panel.add(lblDni);
        panel.add(escribirDNi);
        panel.add(lblSerie);
        panel.add(escribirSerie);
        panel.add(lblPrecio);
        panel.add(escribirPrecio);
        panel.add(cancelar);
        panel.add(guardar);

        add(panel);


        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dni = escribirDNi.getText();
                String nSerie = escribirSerie.getText();
                String precioTexto = escribirPrecio.getText();

                TicketCompra ticketCompra = new TicketCompra(dni,nSerie,precioTexto);


                if (!Validador.comprobarPrecio(precioTexto)) {
                    JOptionPane.showMessageDialog(null, "precio no valido, ejemplo : 10.00 (el punto es importante)");
                    return;
                }

                try {
                    if (!Validador.comprobarPrecio(precioTexto)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el ticket, no se cumplen los requisitos");

                    } else {
                        TicketCompraDAO.insertarCompra(ticketCompra);
                        JOptionPane.showMessageDialog(null, "Compra realizada con exito");
                        TiendaVideojuegoDAO.quitarStock(juegoTienda);
                        dispose();

                        new InterfazGestionTickets().setVisible(true);


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El cliente no puede comprar este juego dos veces.");
                        new InterfazGestionTickets();
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }




            }
        });

        cancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Si cancela, vuelve a empezar el flujo
                new InterfazGestionTickets().setVisible(true);
                dispose();
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

    }
}
