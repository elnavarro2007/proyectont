import Vista.InterfazLogin;

public class Main {
    public static void main(String[] args) {

        new InterfazLogin().setVisible(true);

    }
}