package Modelo;

public class TiendaVideojuegos extends Tienda   {
    private String id_tienda;

    private String num_serie;
    private String Stock;
    private String nombreTienda;
    private String nombreVIdeojuego;





    public TiendaVideojuegos() {
    }

    public TiendaVideojuegos(String id_tienda, String num_serie, String stock) {
        this.id_tienda = id_tienda;
        this.num_serie = num_serie;
        Stock = stock;
    }

    public TiendaVideojuegos(String id_tienda, String num_serie) {
        this.id_tienda = id_tienda;
        this.num_serie = num_serie;
    }





    public String getId_tienda() {
        return id_tienda;
    }

    public void setId_tienda(String id_tienda) {
        this.id_tienda = id_tienda;
    }

    public String getNum_serie() {
        return num_serie;
    }

    public void setNum_serie(String num_serie) {
        this.num_serie = num_serie;
    }

    public String getStock() {
        return Stock;
    }

    public void setStock(String stock) {
        Stock = stock;
    }



    @Override
    public String getNombreTienda() {
        return nombreTienda;
    }

    @Override
    public void setNombreTienda(String nombreTienda) {
        this.nombreTienda = nombreTienda;
    }

    public String getNombreVIdeojuego() {
        return nombreVIdeojuego;
    }

    public void setNombreVIdeojuego(String nombreVIdeojuego) {
        this.nombreVIdeojuego = nombreVIdeojuego;
    }





    @Override
    public String toString() {
        return " || TiendaVideojuegos " +
                "|| id_tienda '" + id_tienda + '\'' +
                "|| nombreTienda '" + nombreTienda + '\'' +
                "|| num_serie '" + num_serie + '\'' +
                "|| nombreVIdeojuego '" + nombreVIdeojuego + '\'' +
                "|| Stock '" + Stock + '\'' +

                "||";
    }
}
