-- Base de datos de tienda de juegos parte de programaciob




-- CREO LA BASE SI NO EXISTE
CREATE DATABASE if not EXISTS tiendaDeVideojuegos;

USE tiendaDeVideojuegos;


CREATE TABLE tienda (
	id int PRIMARY key AUTO_INCREMENT,
	nombre_tienda VARCHAR(40) NOT NULL,
	telefono int(9) NOT NULL,
	ubicacion VARCHAR(100) NOT NULL,
	correo varchar(150) NOT NULL UNIQUE
	
);

CREATE table cliente (

	dni CHAR(9) PRIMARY KEY,
	nombre VARCHAR(30) NOT NULL,
	apellidos VARCHAR(50) NOT NULL,
	telefono CHAR(9) NOT NULL,
	correo VARCHAR(150)NOT NULL UNIQUE





);


create table videojuego (

	numero_serie CHAR(9)  PRIMARY KEY UNIQUE,
	nombre VARCHAR(60) not null UNIQUE,
	genero VARCHAR(20) NOT NULL,
	precio DECIMAL(5,2) NOT NULL DEFAULT 0

);

CREATE TABLE TIENDA_VIDEOJUEGO (
    id_tienda INT,
    num_serie CHAR(9),    
	stock INT NOT NULL DEFAULT 0,
	precio_juego DECIMAL(5,2),
    
	
	CONSTRAINT FK_ID_TIENDA FOREIGN KEY (id_tienda) REFERENCES tienda (id) on delete CASCADE ,
	CONSTRAINT FK_NUMSERIE_TIENDA FOREIGN KEY (num_serie) REFERENCES videojuego (numero_serie) on delete CASCADE
	
	

);


create table cliente_videojuego (
	
	dni_cliente CHAR(9) not null,
    numero_serie CHAR(9) not null,
	precio DECIMAL(5,2),
    
	
	CONSTRAINT FK_DNI_CLIENTE FOREIGN KEY (dni_cliente) REFERENCES cliente (dni) on delete CASCADE ,
	CONSTRAINT FK_NUM_SERIE FOREIGN KEY (numero_Serie) REFERENCES videojuego (numero_serie) on delete CASCADE
	
	
	
	
  


);

 CREATE TABLE usuarios (
     dni CHAR(9) PRIMARY KEY,
     nombre VARCHAR(20) UNIQUE  ,
     password VARCHAR(75) ,
	 
	 
	 CONSTRAINT fk_dni_user FOREIGN KEY (dni) REFERENCES cliente(dni) on delete CASCADE
	 
	 
	);
	
-- Modificaciones
	
ALTER TABLE tienda_videojuego ADD CONSTRAINT unique_tienda_juego UNIQUE (id_tienda, num_serie);
ALTER TABLE cliente_videojuego ADD CONSTRAINT unique_ticket_juego UNIQUE (dni_cliente, numero_serie);


-- Inserciones (la del admin es importante)

INSERT INTO cliente (dni, nombre, apellidos, telefono, correo ) VALUES ('12312312A', 'Admin', ' ',  60000000, 'admin@tienda.com');
INSERT INTO usuarios (dni,nombre,password) VALUES ('12312312A','admin', '1234');

INSERT INTO tienda (nombre_tienda, telefono, ubicacion, correo) VALUES 
('GameHub Central', 912345678, 'Calle Mayor 45, Madrid', 'central@gamehub.com'),
('Pixel Store', 934567890, 'Avenida Diagonal 230, Barcelona', 'info@pixelstore.es'),
('RetroZone', 965432109, 'Plaza del Carmen 12, Valencia', 'contacto@retrozone.com');

INSERT INTO videojuego (numero_serie, nombre, genero, precio) VALUES 
('11500123Z', 'The Legend of Zelda: Breath of the Wild', 'Aventura', 49.99),
('12500123V', 'Persona 3', 'RPG', 59.99),
('12400987A', 'Chrono Trigger', 'JRPG', 39.99),
('12300456S', 'Inazuma Eleven : victory road', 'futbol', 44.99),
('12200111A', 'Sonic 3 y knuckles', 'Plataformas', 29.99),
('12500123M', 'Crazy taxi', 'arcade', 54.99),
('12400987N', 'Mario kart world', 'Carreras', 49.99),
('12300456V', 'Yakuza Kiwami  ', 'peleas', 39.99),
('12308454V', 'Unbeatable  ', 'ritmo', 19.50),
('12509123L', 'Microsoft flight simulator', 'simulacion', 34.99),
('12509223M', 'Danganronpa ', 'novela', 19.99),
('12539123M', 'Dead Cells ', 'Roguelite', 14.00),
('18939223M', 'Postal 2 ', 'Shooter', 9.75),
('11500116S', 'Sonic Frontiers', 'Plataformas', 39.99),
('11500117S', 'Sonic Mania', 'Plataformas', 19.99),
('11500118S', 'Like a Dragon: Infinite Wealth', 'Accion', 59.99),
('11500119S', 'Persona 5 Royal', 'RPG', 49.99),
('11500120S', 'Jet Set Radio Future', 'Accion', 24.99),
('11500121S', 'Crazy Taxi 2', 'Carreras', 14.99),
('11500122S', 'Yakuza 0', 'Accion', 19.99),
('11500123S', 'Valkyria Chronicles', 'Estrategia', 29.99),
('11500124S', 'Phantasy Star Online 2', 'RPG', 6.00),
('11500125S', 'Sonic Adventure 2', 'Plataformas', 24.99),
('11500137V', 'Half-Life 2', 'Shooter', 9.99),
('11500138V', 'Portal 2', 'Puzzle', 9.99),
('11500147J', 'Octopath Traveler II', 'RPG', 49.99),
('11500148J', 'Metaphor: ReFantazio', 'RPG', 59.99),
('11500149J', 'Persona 5 Strikers', 'Accion', 39.99),
('11500150J', 'Nier: Automata', 'Accion', 39.99),
('11500151N', 'Super Mario Bros. Wonder', 'Plataformas', 49.99),
('11500152N', 'Paper Mario: The Thousand-Year Door', 'RPG', 49.99),
('11500153N', 'Donkey Kong Country Returns HD', 'Plataformas', 39.99),
('11500154N', 'Advance Wars 1+2: Re-Boot Camp', 'Estrategia', 44.99),
('11500155N', 'Bayonetta 3', 'Accion', 49.99)
;



INSERT INTO cliente (dni, nombre, apellidos, telefono, correo) VALUES 
('87654321B', 'Laura', 'Garcia', 678123456, 'laura.garcia@email.com'),
('11223344C', 'Carlos', 'Martinez', 654987321, 'carlos.mr@email.com'),
('55667788D', 'Ana', 'Fernandez ', 689456123, 'ana.fernandez@email.com');

INSERT INTO cliente_videojuego (dni_cliente, numero_serie, precio) VALUES 
('87654321B', '12500123V', 49.99),
('87654321B', '11500123Z', 59.99),
('11223344C', '12200111A', 29.99),          
('11223344C', '12300456V', 39.99),
('55667788D', '12500123M', 54.99),
('55667788D', '18939223M', 9.75)
;



INSERT INTO usuarios (dni, nombre, password) VALUES 
('87654321B', 'laura123', 'laura123'),
('11223344C', 'Carlangas11037', 'carlos123'),
('55667788D', 'noSoyAna', 'ana12345');






