package Vista;

import Configuracion.ArchivoLogin;
import ControladorDAO.UsuarioDAO;
import Modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class InterfazLogin extends JFrame {

    public InterfazLogin() {
        // Configuración de la ventana
        setTitle("Inicio de Sesión");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Botones y y textos
        JLabel dni = new JLabel("Dni :");
        JTextField escribirDni = new JTextField();
        JLabel nombre = new JLabel("Nombre :");
        JTextField escribirNombre = new JTextField();
        JLabel password = new JLabel("Contraseña:");
        JPasswordField escrbirPassword = new JPasswordField(); // Este boton me permite que los caracteres se oculten cuando los pongo
        JButton loginButton = new JButton("Entrar");


        panel.add(dni);
        panel.add(escribirDni);
        panel.add(nombre);
        panel.add(escribirNombre);
        panel.add(password);
        panel.add(escrbirPassword);
        panel.add(new JLabel());
        panel.add(loginButton);

        add(panel);

        // Las acciones que hara cuando clickee el boton
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String obtenerDni = escribirDni.getText().trim();
                String usuarioNombre = escribirNombre.getText().trim();
                String getpassword = new String(escrbirPassword.getPassword()).trim();



                Usuario usuario = new Usuario(obtenerDni, usuarioNombre, getpassword);
                if (obtenerDni.isEmpty() && usuarioNombre.isEmpty() && getpassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "rellena los campos");
                } else if (obtenerDni.isEmpty() || usuarioNombre.isEmpty() || getpassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "rellena los campos faltantes");

                } else {


                    if (UsuarioDAO.compruebaUsuarioLogin(usuario)) {
                        JOptionPane.showMessageDialog(null, "Usuario Correcto");
                        dispose();
                        ArchivoLogin.registrarLogin(usuario);

                        if (obtenerDni.equals("12312312A")) {
                            InterfazDelAdmin gestion = new InterfazDelAdmin();
                            gestion.setVisible(true);
                        } else {
                            new InterfazDelCliente(usuario).setVisible(true);
                        }


                    } else {
                        JOptionPane.showMessageDialog(null, "Usuario o Contraseña incorrecto");
                        ArchivoLogin.registrarLogin(usuario);
                    }
                }
            }
        });


        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });





    }

  public  static void main(String[] args) {
        // Para que pueda iniciar el programa desde el login

        new InterfazLogin().setVisible(true);

    }
}
