package Vista.InterfacesSeleccion;

import ControladorDAO.ClienteDAO;
import Modelo.Cliente;
import Vista.InterfacesUsuarios.InterfazAñadirUsuario;
import Vista.InterfacesUsuarios.InterfazGestionUsuarios;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
/*Pasos que hago :
 * Añado los atributos para que ninguna clase pueda acceder a otras
 * Defino los ajustes de la interfaz
 * Le dijo a tiendas de donde debe obtener los datos de las tablas
 * Defino las columnas de la interfaz y las añado a la tabla tienda
 * hago el foreach para ir obteniendo los datos de la tabla
 * hago que solo pueda seleccionarse un dato a la vez
 * defino una variable que al clickar en ella obtenga sus datos
 * en los diferentes botones cada uno hara su accion correspondiente
 * */
public class InterfazSeleccionarClienteUsuario extends JFrame {

    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;
    private ArrayList<Cliente> clientes;
    public InterfazSeleccionarClienteUsuario() {
        setTitle("seleccionar Cliente Usuario");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));


        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");

        clientes = ClienteDAO.verCliente();
        String[] columnas = {"DNi" ,"Nombre ", "Apellido", "Telefono","Correo"};


        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        for (Cliente c : clientes) {
            Object[] fila = {c.getDni(), c.getNombre(), c.getApellidos(),c.getTelefono(),c.getCorreo()};
            modeloTabla.addRow(fila);
        }

        tablaClientes = new JTable(modeloTabla);
        tablaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);


        JPanel panelScroll = new JPanel();
        JScrollPane scroll = new JScrollPane(tablaClientes);
        scroll.setPreferredSize(new Dimension(600, 350));
        panelBotones.add(volver);
        panelBotones.add(seleccionar);


        // panelTexto.add(obtenerDNI);
        panel.add(panelTexto, BorderLayout.NORTH);
        panelScroll.add(scroll);
        panel.add(panelBotones, BorderLayout.SOUTH);


        panel.add(panelScroll, BorderLayout.CENTER);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionUsuarios interfazGestionTickets = new InterfazGestionUsuarios();
                dispose();
            }
        });
        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaClientes.getSelectedRow();
                if (filaSeleccionada == -1 ) {
                    JOptionPane.showMessageDialog(null, "Cliente no seleccionado");
                } else {


                    Cliente clienteSeleccionado = clientes.get(filaSeleccionada);

                        new InterfazAñadirUsuario(clienteSeleccionado).setVisible(true);
                        dispose();


                }
            }
        });


        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }
}
