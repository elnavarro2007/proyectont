package Vista.InterfacesSeleccion;

import ControladorDAO.TiendaVideojuegoDAO;
import Modelo.TiendaVideojuegos;
import Vista.InterfacesTickets.InterfazGestionTickets;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
/*Pasos que hago :
 * Añado los atributos para que ninguna clase pueda acceder a otras
 * Defino los ajustes de la interfaz
 * Le dijo a tiendas de donde debe obtener los datos de las tablas
 * Defino las columnas de la interfaz y las añado a la tabla tienda
 * hago el foreach para ir obteniendo los datos de la tabla
 * hago que solo pueda seleccionarse un dato a la vez
 * defino una variable que al clickar en ella obtenga sus datos
 * en los diferentes botones cada uno hara su accion correspondiente
 * */
public class InterfazSeleccionarStockTicket extends JFrame {
    private JTable tablaStock;
    private DefaultTableModel modeloTabla;
    private ArrayList<TiendaVideojuegos> stock;

    public InterfazSeleccionarStockTicket() {
        setTitle("seleccionar Tienda ticket");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("volver");
        JButton seleccionar = new JButton("seleccionar");

        stock = TiendaVideojuegoDAO.verStock();

        String[] columnas = {"Nombre de Tienda", "Numero serie", "Videojuego","stock"};

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (TiendaVideojuegos t : stock) {
            Object[] fila = { t.getNombreTienda(), t.getNum_serie(),t.getNombreVIdeojuego(),t.getStock()};
            modeloTabla.addRow(fila);
        }

        tablaStock = new JTable(modeloTabla);
        tablaStock.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tablaStock);
        scroll.setPreferredSize(new Dimension(600, 350));

        panelBotones.add(volver);
        panelBotones.add(seleccionar);

        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new InterfazGestionTickets();
                dispose();
            }
        });


        seleccionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaStock.getSelectedRow();
                if (filaSeleccionada == -1 ) {
                    JOptionPane.showMessageDialog(null, "Juego de la tienda no seleccionado");
                } else {


                    TiendaVideojuegos juegoSeleccionado = stock.get(filaSeleccionada);
                    if(juegoSeleccionado.getStock().equals("0")){
                        JOptionPane.showMessageDialog(null, " No queda stock suficiente");
                    }else {
                        new InterfazSeleccionarClienteTicket(juegoSeleccionado).setVisible(true);
                        dispose();
                    }

                }
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }

}
