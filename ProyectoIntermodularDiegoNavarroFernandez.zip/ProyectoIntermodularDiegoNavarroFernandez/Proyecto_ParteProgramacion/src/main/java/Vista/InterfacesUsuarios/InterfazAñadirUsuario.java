package Vista.InterfacesUsuarios;

import ControladorDAO.UsuarioDAO;
import Modelo.Cliente;
import Modelo.Usuario;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfazAñadirUsuario extends JFrame {

    public InterfazAñadirUsuario(Cliente cliente) {

        setTitle("añadir usuario");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        // Panel principal 3 filas, 2 columnas
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel dni = new JLabel("DNI");
        JLabel nombre = new JLabel("nombre");
        JLabel contrasena = new JLabel("contraseña");
        JButton volver = new JButton("volver");
        JButton añadir = new JButton("añadir");
        JTextField escribirDni = new JTextField(cliente.getDni());
        escribirDni.setEditable(false);
        JPasswordField escribirContraseña = new JPasswordField();
        JTextField escribirNombre = new JTextField();
        panel.add(dni);
        panel.add(escribirDni);
        panel.add(nombre);
        panel.add(escribirNombre);
        panel.add(contrasena);
        panel.add(escribirContraseña);
        panel.add(volver);
        panel.add(añadir);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionUsuarios interfazGestionUsuarios = new InterfazGestionUsuarios();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = escribirNombre.getText().trim();
                String dni = escribirDni.getText().trim();
                String contrasena = escribirContraseña.getText();

                Usuario usuario = new Usuario(dni, nombre, contrasena);

                if(nombre.isEmpty() || dni.isEmpty() || contrasena.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Rellena todos los campos ");
                    return;
                }


                if (!Validador.comprobarNombreUsuario(nombre)) {
                    JOptionPane.showMessageDialog(null, "Solo caracteres del abecedario nombre entre 4 y 20 caracteres Ejemplo : nAvarro07ñ");
                    return;
                }
                if (!Validador.comprobarDNI(dni)) {
                    JOptionPane.showMessageDialog(null, "el dni es incorrecto ejemplo : 11037111Z");
                    return;
                }
                if (!Validador.comprobarPassword(contrasena)) {
                    JOptionPane.showMessageDialog(null, "La contraseña debe tener minimo 8 caracteres, ejemplo : Dam12345");
                    return;
                }




                try {
                    if (!Validador.comprobarNombreUsuario(nombre) || !Validador.comprobarDNI(dni) || !Validador.comprobarPassword(contrasena)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el usuario, no se cumplen los requisitos");

                    } else {
                        UsuarioDAO.insertarUsuario(usuario);
                        JOptionPane.showMessageDialog(null, "Usuario añadido con exito");
                        dispose();
                        new InterfazGestionUsuarios();

                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "El usuario ya existe o existen dos usernames iguales");
                        dispose();
                        new InterfazGestionUsuarios().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });




    }


}
