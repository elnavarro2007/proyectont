package Vista.InterfacesVideojuegos;

import ControladorDAO.VideojuegoDAO;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*Introduzco todos los valores, se los paso a un objeto con todos los parametros
* los paso por unos validadores para que verifique
* todo, si se cumple todos los requisitos, se añade el objeto a la base de datos*/

public class InterfazAñadirVideojuegos extends JFrame {

    public InterfazAñadirVideojuegos() {

        setTitle("añadir videojuego");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel numeroSerie = new JLabel("numero serie");
        JLabel nombre = new JLabel("nombre");
        JLabel genero = new JLabel("genero");
        JLabel precio = new JLabel("precio");
        JButton volver = new JButton("volver");
        JButton añadir = new JButton("añadir");
        JTextField escribirNumeroSerie = new JTextField();
        JTextField escribirNombre = new JTextField();
        JTextField escribirGenero = new JTextField();
        JTextField escribirPrecio = new JTextField();

        panel.add(numeroSerie);
        panel.add(escribirNumeroSerie);
        panel.add(nombre);
        panel.add(escribirNombre);
        panel.add(genero);
        panel.add(escribirGenero);
        panel.add(precio);
        panel.add(escribirPrecio);
        panel.add(volver);
        panel.add(añadir);
        add(panel);

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionVideojuegos interfazGestionVideojuegos = new InterfazGestionVideojuegos();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String numeroSerie = escribirNumeroSerie.getText().trim();
                String nombre = escribirNombre.getText().trim();
                String genero = escribirGenero.getText();
                String precio = escribirPrecio.getText().trim();


                Videojuegos videojuegos = new Videojuegos(numeroSerie, nombre, genero, precio);

                if(numeroSerie.isEmpty() ||nombre.isEmpty() ||genero.isEmpty() || precio.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Rellena todos los campos");
                    return;
                }

                // Validadores

                if (!Validador.comprobarNumSerie(numeroSerie)) {
                    JOptionPane.showMessageDialog(null, "el numero de serie es incorrecto, debe seguir el formato de ejemplo : 11037111Z");
                    return;
                }
                if (!Validador.comprobarNombreVideojuego(nombre)) {
                    JOptionPane.showMessageDialog(null, " max 80 caracteres  Ejemplo : Persona 3 , Yakuza, Devil Survivor");
                    return;
                }

                if (!Validador.comprobarGenero(genero)) {
                    JOptionPane.showMessageDialog(null, "Solo puedes introducir un genero por juego, ejemplo : RPG, Accion");
                    return;
                }
                if (!Validador.comprobarPrecio(precio)) {
                    JOptionPane.showMessageDialog(null, "precio no valido, ejemplo : 10.00 (EL PUNTO ES IMPORTANTE PARA MARCAR DECIMALES)");
                    return;
                }


                try {


                    if (!Validador.comprobarNombreVideojuego(nombre) || !Validador.comprobarNumSerie(numeroSerie) || !Validador.comprobarGenero(genero) || !Validador.comprobarPrecio(precio)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el videojuego, no se cumple los requisitos");

                    } else {
                        VideojuegoDAO.insertarVideojuego(videojuegos);
                        JOptionPane.showMessageDialog(null, "Videojuego añadido con exito");
                        dispose();
                        new InterfazGestionVideojuegos();

                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry")) {
                        JOptionPane.showMessageDialog(null, "El número de serie ya existe y el nombre no puede repetirse");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });





    }


}
