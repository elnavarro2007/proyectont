package Vista.InterfacesVideojuegos;

import ControladorDAO.VideojuegoDAO;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*Pasos que realizo :
 * Pillo el objeto de la interfaz anterior para pasarlo a esta nueva,
 * obtengo sus atributos y hago que se puedan modificar solo los necesarios*/

public class ModificarVideojuegos extends JFrame {
    public ModificarVideojuegos(Videojuegos videojuegos) {

        setTitle("Modificar videojuegos");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
        setResizable(false);

        JPanel panelModificar = new JPanel(new GridLayout(5, 2, 5, 5));
        panelModificar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel id = new JLabel("numero serie");
        JLabel nombre = new JLabel("nombre");
        JLabel genero = new JLabel(" genero");

        JLabel precio = new JLabel("Precio");


        JTextField escribirID = new JTextField(videojuegos.getNumeroSerie());
        escribirID.setEditable(false);
        JTextField escribirNombre = new JTextField(videojuegos.getNombre());
        JTextField escribirGenero = new JTextField(videojuegos.getGenero());

        JTextField escribirPrecio = new JTextField(videojuegos.getPrecio());


        JButton modificar = new JButton("modificar");
        JButton volver = new JButton("volver");

        panelModificar.add(id);
        panelModificar.add(escribirID);
        panelModificar.add(nombre);
        panelModificar.add(escribirNombre);
        panelModificar.add(genero);
        panelModificar.add(escribirGenero);
        panelModificar.add(precio);
        panelModificar.add(escribirPrecio);



        panelModificar.add(volver);
        panelModificar.add(modificar);
        add(panelModificar);


        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String id = escribirID.getText();
                String nombre = escribirNombre.getText();
                String genero = escribirGenero.getText().trim();
                String precio = escribirPrecio.getText().trim();


                Videojuegos videojuegos1 = new Videojuegos(id, nombre, genero, precio);


                // Validadores
                if (!Validador.comprobarNumSerie(id)) {
                    JOptionPane.showMessageDialog(null, "el numero de serie es incorrecto, necesita 8 numeros y un caracter ejemplo : 11037111Z");
                    return;
                }
                if (!Validador.comprobarNombreVideojuego(nombre)) {
                    JOptionPane.showMessageDialog(null, " max 50 caracteres  Ejemplo : Persona 3 , Yakuza, Devil Survivor");
                    return;
                }

                if (!Validador.comprobarGenero(genero)) {
                    JOptionPane.showMessageDialog(null, "Solo puedes introducir un genero por juego, ejemplo : RPG, Accion");
                    return;
                }
                if (!Validador.comprobarPrecio(precio)) {
                    JOptionPane.showMessageDialog(null, "precio no valido, ejemplo : 10.00 (el punto es importante)");
                    return;
                }


                try {


                    if (!Validador.comprobarNombreVideojuego(nombre) || !Validador.comprobarNumSerie(id) || !Validador.comprobarGenero(genero) || !Validador.comprobarPrecio(precio)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido modificar el juego, no se cumplen los requisitos");

                    } else {
                        VideojuegoDAO.actualizarVideojuego(videojuegos1);
                        JOptionPane.showMessageDialog(null, "Videojuego modificado con exito");
                        dispose();
                        new InterfazVerVideojuegos().setVisible(true);


                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry")) {
                        JOptionPane.showMessageDialog(null, "El número de serie ya existe");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazVerVideojuegos interfazVerVideojuegos = new InterfazVerVideojuegos();
                dispose();
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });



    }
}
