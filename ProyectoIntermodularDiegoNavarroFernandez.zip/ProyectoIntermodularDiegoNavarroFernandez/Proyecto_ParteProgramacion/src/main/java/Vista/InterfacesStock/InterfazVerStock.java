package Vista.InterfacesStock;

import ControladorDAO.TiendaVideojuegoDAO;
import Modelo.TiendaVideojuegos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
/*Pasos que hago :
 * Añado los atributos para que ninguna clase pueda acceder a otras
 * Defino los ajustes de la interfaz
 * Le dijo a tiendas de donde debe obtener los datos de las tablas
 * Defino las columnas de la interfaz y las añado a la tabla tienda
 * hago el foreach para ir obteniendo los datos de la tabla
 * hago que solo pueda seleccionarse un dato a la vez
 * defino una variable que al clickar en ella obtenga sus datos
 * en los diferentes botones cada uno hara su accion correspondiente
 * */
public class InterfazVerStock extends JFrame {

    private JTable tablaStock;
    private DefaultTableModel modeloTabla;
    private ArrayList<TiendaVideojuegos> stock; // Guardo la lista para relacionar el índice de la tabla

    public InterfazVerStock() {
        setTitle("Ver Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setResizable(false);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel panelTexto = new JPanel(new GridLayout(1, 5, 5, 5));

        JPanel panelBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton volver = new JButton("Volver");
        JButton actualizar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");

        stock = TiendaVideojuegoDAO.verStock();

        String[] columnas = {"ID", "Nombre", "numero_Serie", "Videojuego", "stock"};


        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hago que las celdas no se puedan editar si se clickan
            }
        };

        for (TiendaVideojuegos t : stock) {
            Object[] fila = {t.getId_tienda(), t.getNombreTienda(), t.getNum_serie(), t.getNombreVIdeojuego(), t.getStock()};
            modeloTabla.addRow(fila);
        }

        tablaStock = new JTable(modeloTabla);
        tablaStock.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tablaStock);
        scroll.setPreferredSize(new Dimension(600, 400));

        panelBotones.add(volver);
        panelBotones.add(actualizar);
        panelBotones.add(eliminar);

        panel.add(panelTexto, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);

        // Listeners

        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new InterfazGestionStock();
                dispose();
            }
        });

        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaStock.getSelectedRow();

                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "No se ha seleccionado stock");
                } else {
                    TiendaVideojuegos seleccionado = stock.get(filaSeleccionada);

                    int respuesta = JOptionPane.showConfirmDialog(null,
                            "Seguro que quieres eliminar el Stock? ",
                            "Confirmar eliminacion", JOptionPane.YES_NO_OPTION);

                    if (respuesta == JOptionPane.YES_OPTION) {
                        boolean eliminado = TiendaVideojuegoDAO.eliminarTiendaVideojuego(seleccionado);
                        JOptionPane.showMessageDialog(null, "Eliminado con éxito");
                        dispose();
                        new InterfazVerStock();
                    }else {

                    }
                }
            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });







    }


}

