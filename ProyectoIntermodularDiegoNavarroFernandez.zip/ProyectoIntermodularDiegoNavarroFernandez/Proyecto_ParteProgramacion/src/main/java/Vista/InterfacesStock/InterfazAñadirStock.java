package Vista.InterfacesStock;

import ControladorDAO.TiendaVideojuegoDAO;
import Modelo.Tienda;
import Modelo.TiendaVideojuegos;
import Modelo.Videojuegos;
import Utils.Validador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/*En esta interfaz le paso los objetos seleccionados de las interfaces anteriores,
 */

public class InterfazAñadirStock extends JFrame {
    public InterfazAñadirStock(Tienda tienda, Videojuegos videojuegos) {

        setTitle("Añadir Stock");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla
        setVisible(true);
        setResizable(false);


        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));


        JLabel stock = new JLabel("stock");
        JLabel nombreTienda = new JLabel("nombre tienda");
        JLabel nombreVideojuego = new JLabel("Videojuego");



        JTextField escribirid = new JTextField(tienda.getId());
        escribirid.setEditable(false);
        escribirid.setVisible(false);

        JTextField escribirNombre = new JTextField(tienda.getNombreTienda());
        escribirNombre.setEditable(false);

        JTextField escribirNombreVideojuego = new JTextField(videojuegos.getNombre());
        escribirNombreVideojuego.setEditable(false);

        JTextField escribirserie = new JTextField(videojuegos.getNumeroSerie());
        escribirserie.setEditable(false);
        escribirserie.setVisible(false);


        JTextField escribirstok = new JTextField();

        JButton añadir = new JButton("añadir");
        JButton volver = new JButton("volver");

        panel.add(nombreTienda);
        panel.add(escribirNombre);
        panel.add(nombreVideojuego);
        panel.add(escribirNombreVideojuego);
        panel.add(stock);
        panel.add(escribirstok);
        panel.add(volver);
        panel.add(añadir);

        add(panel);
        volver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                dispose();
            }
        });
        añadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = escribirid.getText().trim();
                String numero_serie = escribirserie.getText().trim();
                String stock = escribirstok.getText().trim();

                TiendaVideojuegos tiendaVideojuegos = new TiendaVideojuegos(id, numero_serie, stock);

                if (!Validador.comprobarStock(stock)) {
                    JOptionPane.showMessageDialog(null, "Maximo 5 cifras sin decimales y sin letras, si no pone nada, sera 0");
                    return;
                }


                try {
                    if (!Validador.comprobarStock(stock)) {

                        JOptionPane.showMessageDialog(null, " No se ha podido añadir el stock");

                    } else {
                        TiendaVideojuegoDAO.insertarTiendaVideojuego(tiendaVideojuegos);
                        JOptionPane.showMessageDialog(null, "Stock añadido con exito");
                        dispose();
                        new InterfazGestionStock();

                    }
                } catch (Exception ex) {
                    if (ex.getMessage().contains("Duplicate entry") || ex.getMessage().contains("violates unique constraint")) {
                        JOptionPane.showMessageDialog(null, "No puede haber dos juegos en una misma tienda.");
                        dispose();
                        new InterfazGestionStock().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al guardar: " + ex.getMessage());
                    }
                }


            }
        });

        // el do nothing on close Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });


    }

}
