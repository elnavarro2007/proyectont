package Vista;

import ControladorDAO.TiendaDAO;
import Vista.InterfacesCliente.InterfazGestionClientes;
import Vista.InterfacesStock.InterfazGestionStock;
import Vista.InterfacesTickets.InterfazGestionTickets;
import Vista.InterfacesVideojuegos.InterfazGestionVideojuegos;
import Vista.InterfacesUsuarios.InterfazGestionUsuarios;
import Vista.interfacesTienda.InterfazGestionTienda;
import Vista.interfacesTienda.InterfazVerTienda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfazDelAdmin extends JFrame {


    public InterfazDelAdmin() {
        setTitle("Gestion De elementos");
        setSize(640, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en pantalla

        JPanel panel = new JPanel(new GridLayout(2, 3, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setVisible(true);
        setResizable(false);

        JButton botonTienda = new JButton(" Tienda");
        JButton botonClientes = new JButton("Clientes");
        JButton botonVideojuegos = new JButton("Videojuegos");
        JButton botonStock = new JButton("Stock");
        JButton botonTickets = new JButton("Tickets");
        JButton botonUsers = new JButton("Usuarios");

        panel.add(botonTienda);
        panel.add(botonClientes);
        panel.add(botonVideojuegos);
        panel.add(botonStock);
        panel.add(botonTickets);
        panel.add(botonUsers);

        add(panel);



        // acciones de los botones

        botonTienda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTienda interfazGestionTienda = new InterfazGestionTienda();
                interfazGestionTienda.setVisible(true);
                dispose();
            }
        });

        botonClientes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionClientes interfazGestionClientes = new InterfazGestionClientes();
                interfazGestionClientes.setVisible(true);
                dispose();
            }
        });
        botonVideojuegos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionVideojuegos interfazGestionVideojuegos = new InterfazGestionVideojuegos();
                interfazGestionVideojuegos.setVisible(true);
                dispose();
            }
        });

        botonStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionStock interfazGestionStock = new InterfazGestionStock();
                interfazGestionStock.setVisible(true);
                dispose();
            }
        });

        botonTickets.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionTickets interfazGestionTickets = new InterfazGestionTickets();
                interfazGestionTickets.setVisible(true);
                dispose();
            }
        });
        botonUsers.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfazGestionUsuarios interfazGestionUsuarios = new InterfazGestionUsuarios();
                interfazGestionUsuarios.setVisible(true);
                dispose();
            }
        });

        // Me permite que al darle que no se cierre no se cierre todo
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?",
                        "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

                if (respuesta == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });









    }


   public static void main(String[] args) {
        new InterfazDelAdmin().setVisible(true);
    }
}
